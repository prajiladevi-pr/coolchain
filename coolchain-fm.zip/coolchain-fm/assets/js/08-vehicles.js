/* =====================================================================
   CoolChain FM — Vehicle management
   assets/js/08-vehicles.js

   Fleet register, add and edit vehicle, vehicle profile and trip history.
   ===================================================================== */

function filterVeh(){
  const f=F.vh,q=f.q.toLowerCase();
  return S.vehicles.filter(v=>{
    if(f.status&&vStatus(v.id)!==f.status)return false;
    if(f.type&&v.type!==f.type)return false;
    if(f.loc&&v.location!==f.loc)return false;
    if(q&&![v.reg,v.make,v.model,v.type,v.location,v.emirates].join(' ').toLowerCase().includes(q))return false;
    return true;
  });
}
const VTYPES=['Service Van','Pickup','Crane Truck','Car'];
function vVehicles(){
  const f=F.vh,list=filterVeh();
  const soon=S.vehicles.filter(v=>v.insuranceExpiry-now()<60*864e5);
  return `<div class="stat-grid" style="margin-bottom:18px">
    ${statCard('Total vehicles',S.vehicles.length,'Service fleet')}
    ${statCard('Available',S.vehicles.filter(v=>vStatus(v.id)==='Available').length,'Ready to dispatch','c')}
    ${statCard('Assigned',S.vehicles.filter(v=>vStatus(v.id)==='Assigned').length,'Allocated to a request','v')}
    ${statCard('In service',S.vehicles.filter(v=>vStatus(v.id)==='In Service').length,'Out on a job','w')}
    ${statCard('Maintenance',S.vehicles.filter(v=>vStatus(v.id)==='Maintenance').length,'Off road','h')}
    ${statCard('Insurance due',soon.length,'Within 60 days','h')}
  </div>
  <div class="card">
    <div class="bar-tools">
      <div class="search">${icon('search',15)}<input class="inp" placeholder="Search registration, make, model…" value="${esc(f.q)}" oninput="F.vh.q=this.value;$('#vTable').innerHTML=vTable(filterVeh())"></div>
      <select class="inp" onchange="setF('vh','status',this.value)">${opts(VSTATUS,f.status,'All statuses')}</select>
      <select class="inp" onchange="setF('vh','type',this.value)">${opts(VTYPES,f.type,'All types')}</select>
      <select class="inp" onchange="setF('vh','loc',this.value)">${opts([...new Set(S.vehicles.map(v=>v.location))],f.loc,'All locations')}</select>
      <button class="btn btn-sm" onclick="clearF('vh')">Clear</button>
      <button class="btn btn-sm btn-cool" style="margin-left:auto" onclick="openVeh()">${icon('plus',14)} Add vehicle</button>
    </div>
    <div id="vTable">${vTable(list)}</div>
  </div>`;
}
function vTable(list){
  if(!list.length)return `<div class="t-empty"><b>No vehicles match</b>Try a different status or location.</div>`;
  return `<div class="tbl-wrap"><table>
  <thead><tr><th>Registration</th><th>Type</th><th>Model</th><th>Driver</th><th>Supervisor</th><th>Location</th><th>Current assignment</th><th>Status</th><th>Service due</th><th>Insurance expiry</th><th>Actions</th></tr></thead>
  <tbody>${list.map(v=>{
    const c=curSRVeh(v.id),insSoon=v.insuranceExpiry-now()<60*864e5;
    return `<tr>
    <td><b class="mono">${esc(v.reg)}</b><div class="eyebrow">${v.year}</div></td>
    <td>${esc(v.type)}</td><td>${esc(v.make)} ${esc(v.model)}<div style="color:var(--txt-3);font-size:11.5px">${esc(v.fuel)}</div></td>
    <td>${v.driverId?`<div class="who">${av(user(v.driverId).name,26)}<b>${esc(user(v.driverId).name)}</b></div>`:'<span style="color:var(--txt-3)">Unassigned</span>'}</td>
    <td>${v.supId?esc(user(v.supId).name):'—'}</td>
    <td>${esc(v.location)}<div style="color:var(--txt-3);font-size:11.5px">${esc(v.emirates)}</div></td>
    <td>${c?`<span class="sr-no">#${c.srNo}</span><div style="font-size:11.5px;color:var(--txt-3)">${esc(c.client)}</div>`:'<span style="color:var(--txt-3)">—</span>'}</td>
    <td>${bdg(vStatus(v.id))}</td>
    <td class="mono" style="font-size:11.5px">${fmtDate(v.serviceDue)}</td>
    <td class="mono" style="font-size:11.5px;${insSoon?'color:var(--hot);font-weight:600':''}">${fmtDate(v.insuranceExpiry)}</td>
    <td><div class="acts">
      <button class="btn btn-icon" title="View" onclick="viewVeh('${v.id}')">${icon('eye',14)}</button>
      <button class="btn btn-icon" title="Edit" onclick="openVeh('${v.id}')">${icon('pen',14)}</button>
      <button class="btn btn-icon" title="Vehicle history" onclick="vehHistory('${v.id}')">${icon('hist',14)}</button>
    </div></td></tr>`}).join('')}</tbody></table></div>`;
}
let vdraft=null;
function openVeh(id){
  const v=id?veh(id):null;
  vdraft=v?Object.assign({},v):{id:uid('V'),reg:'',type:'Service Van',make:'',model:'',year:new Date().getFullYear(),fuel:'Diesel',
    capacity:'3 crew + tools',location:'',emirates:'Dubai',driverId:null,supId:null,base:'Available',
    insuranceExpiry:now()+300*864e5,regExpiry:now()+300*864e5,fitnessExpiry:now()+300*864e5,serviceDue:now()+60*864e5,notes:''};
  vdraft.__edit=!!v;
  const dstr=ts=>{const x=new Date(ts||now());return `${x.getFullYear()}-${pad(x.getMonth()+1)}-${pad(x.getDate())}`};
  modal({title:v?'Edit '+v.reg:'Add vehicle',eyebrow:v?'Fleet record':'Fleet master data',wide:true,
    body:`<div class="grid3">
      <div class="field"><label>Registration number</label><input class="inp mono" value="${esc(vdraft.reg)}" placeholder="DXB-1234" oninput="vdraft.reg=this.value"></div>
      <div class="field"><label>Vehicle type</label><select class="inp" onchange="vdraft.type=this.value">${opts(VTYPES,vdraft.type,'Select')}</select></div>
      <div class="field"><label>Fuel type</label><select class="inp" onchange="vdraft.fuel=this.value">${opts(['Diesel','Petrol','Hybrid','Electric'],vdraft.fuel,'Select')}</select></div>
    </div>
    <div class="grid3">
      <div class="field"><label>Manufacturer</label><input class="inp" value="${esc(vdraft.make)}" placeholder="Toyota" oninput="vdraft.make=this.value"></div>
      <div class="field"><label>Model</label><input class="inp" value="${esc(vdraft.model)}" placeholder="Hiace" oninput="vdraft.model=this.value"></div>
      <div class="field"><label>Year</label><input class="inp mono" type="number" value="${vdraft.year}" oninput="vdraft.year=Number(this.value)"></div>
    </div>
    <div class="grid3">
      <div class="field"><label>Capacity</label><input class="inp" value="${esc(vdraft.capacity)}" oninput="vdraft.capacity=this.value"></div>
      <div class="field"><label>Current location</label><input class="inp" list="dlAreas3" value="${esc(vdraft.location)}" oninput="vdraft.location=this.value">
        <datalist id="dlAreas3">${AREAS.map(a=>`<option value="${esc(a)}">`).join('')}</datalist></div>
      <div class="field"><label>Emirates</label><select class="inp" onchange="vdraft.emirates=this.value">${opts(EMIRATES,vdraft.emirates,'Select')}</select></div>
    </div>
    <div class="grid3">
      <div class="field"><label>Assigned driver</label><select class="inp" onchange="vdraft.driverId=this.value||null">${opts(S.users.filter(u=>u.role==='Driver').map(u=>({v:u.id,l:u.name})),vdraft.driverId,'Unassigned')}</select></div>
      <div class="field"><label>Assigned supervisor / team</label><select class="inp" onchange="vdraft.supId=this.value||null">${opts(S.users.filter(u=>u.role==='Supervisor').map(u=>({v:u.id,l:u.name})),vdraft.supId,'Unassigned')}</select></div>
      <div class="field"><label>Status</label><select class="inp" onchange="vdraft.base=this.value">${opts(['Available','Maintenance','Inactive'],vdraft.base,'Select')}</select></div>
    </div>
    <div class="grid2">
      <div class="field"><label>Insurance expiry</label><input class="inp" type="date" value="${dstr(vdraft.insuranceExpiry)}" onchange="vdraft.insuranceExpiry=new Date(this.value).getTime()"></div>
      <div class="field"><label>Registration expiry</label><input class="inp" type="date" value="${dstr(vdraft.regExpiry)}" onchange="vdraft.regExpiry=new Date(this.value).getTime()"></div>
    </div>
    <div class="grid2">
      <div class="field"><label>Fitness expiry</label><input class="inp" type="date" value="${dstr(vdraft.fitnessExpiry)}" onchange="vdraft.fitnessExpiry=new Date(this.value).getTime()"></div>
      <div class="field"><label>Service due date</label><input class="inp" type="date" value="${dstr(vdraft.serviceDue)}" onchange="vdraft.serviceDue=new Date(this.value).getTime()"></div>
    </div>
    <div class="field"><label>Notes</label><textarea class="inp" oninput="vdraft.notes=this.value">${esc(vdraft.notes)}</textarea></div>
    <p style="color:var(--txt-3);font-size:12.5px;margin:0">Assigned and In Service are set automatically while the van is on a live request.</p>`,
    footer:`<button class="btn l" onclick="closeModal()">Cancel</button><button class="btn btn-cool" onclick="saveVeh()">${v?'Save changes':'Add vehicle'}</button>`});
}
function saveVeh(){
  if(!vdraft.reg.trim()){toast('Registration required','Enter the vehicle registration number.','err');return}
  const edit=vdraft.__edit;delete vdraft.__edit;
  if(edit){const i=S.vehicles.findIndex(v=>v.id===vdraft.id);S.vehicles[i]=vdraft;toast('Vehicle updated',vdraft.reg+' saved.','ok')}
  else{S.vehicles.push(vdraft);toast('Vehicle added',vdraft.reg+' · '+vdraft.type,'ok')}
  closeModal();render();
}
function viewVeh(id){
  const v=veh(id),c=curSRVeh(id),jobs=S.requests.filter(r=>r.vehId===id);
  const hrs=jobs.filter(r=>r.hours).reduce((a,r)=>a+r.hours,0);
  modal({title:v.reg,eyebrow:`${v.make} ${v.model} · ${v.type}`,
    body:`<div style="display:flex;gap:8px;margin-bottom:16px;flex-wrap:wrap">${bdg(vStatus(id))}
        <span class="b b-idle b-sq"><i></i>${v.year}</span><span class="b b-idle b-sq"><i></i>${esc(v.fuel)}</span></div>
      <dl class="kv" style="margin-bottom:16px">
        <dt>Capacity</dt><dd>${esc(v.capacity)}</dd>
        <dt>Location</dt><dd>${esc(v.location)}, ${esc(v.emirates)}</dd>
        <dt>Driver</dt><dd>${v.driverId?esc(user(v.driverId).name):'Unassigned'}</dd>
        <dt>Supervisor</dt><dd>${v.supId?esc(user(v.supId).name):'Unassigned'}</dd>
        <dt>Insurance</dt><dd class="mono">${fmtDate(v.insuranceExpiry)}</dd>
        <dt>Registration</dt><dd class="mono">${fmtDate(v.regExpiry)}</dd>
        <dt>Fitness</dt><dd class="mono">${fmtDate(v.fitnessExpiry)}</dd>
        <dt>Service due</dt><dd class="mono">${fmtDate(v.serviceDue)}</dd>
        <dt>Notes</dt><dd>${esc(v.notes||'—')}</dd>
      </dl>
      <div class="panel" style="margin-bottom:14px"><div class="panel-t">Current assignment</div>
        ${c?`<span class="sr-no">#${c.srNo}</span> <b>${esc(c.client)}</b> — ${esc(c.serviceType)}
          <div style="color:var(--txt-2);font-size:12.5px;margin-top:4px">${esc(c.area)}, ${esc(c.emirates)} · supervisor ${esc(sup(c)?sup(c).name:'—')} ${c.timeIn?`· since ${fmtTime(c.timeIn)}`:''}</div>`
        :'<span style="color:var(--txt-3);font-size:13px">Parked and available.</span>'}</div>
      <div class="stat-grid" style="grid-template-columns:repeat(3,1fr)">
        ${statCard('Jobs attended',jobs.length,'','c')}${statCard('Working hours',hrs.toFixed(1),'','w')}
        ${statCard('Completed',jobs.filter(r=>['Work Completed','Closed'].includes(r.status)).length,'','d')}
      </div>`,
    footer:`<button class="btn l" onclick="vehHistory('${v.id}')">${icon('hist',14)} Vehicle history</button>
            <button class="btn" onclick="closeModal()">Close</button><button class="btn btn-cool" onclick="openVeh('${v.id}')">Edit vehicle</button>`});
}
function vehHistory(id){
  const v=veh(id),jobs=S.requests.filter(r=>r.vehId===id).sort((a,b)=>(b.timeIn||b.reportedDate)-(a.timeIn||a.reportedDate));
  modal({title:'Vehicle history — '+v.reg,eyebrow:`${v.make} ${v.model}`,wide:true,
    body:jobs.length?`<div class="tbl-wrap card" style="box-shadow:none"><table>
      <thead><tr><th>Date</th><th>SR No</th><th>Client</th><th>Area</th><th>Service</th><th>Supervisor</th><th>Driver</th><th>Time in</th><th>Time out</th><th>Hours</th><th>Status</th></tr></thead>
      <tbody>${jobs.map(r=>`<tr><td class="mono" style="font-size:11.5px">${fmtDate(r.timeIn||r.reportedDate)}</td>
        <td><span class="sr-no">#${r.srNo}</span></td><td>${esc(r.client)}</td><td>${esc(r.area)}</td><td>${esc(r.serviceType)}</td>
        <td>${sup(r)?esc(sup(r).name):'—'}</td><td>${r.driverId?esc(user(r.driverId).name):'—'}</td>
        <td class="mono">${r.timeIn?fmtTime(r.timeIn):'—'}</td><td class="mono">${r.timeOut?fmtTime(r.timeOut):'—'}</td>
        <td class="mono">${r.hours!=null?r.hours:'—'}</td><td>${bdg(r.status)}</td></tr>`).join('')}</tbody></table></div>`
      :`<div class="t-empty"><b>No trips recorded</b>${esc(v.reg)} has not been assigned to a service request yet.</div>`,
    footer:`<button class="btn" onclick="closeModal()">Close</button>`});
}
