/* =====================================================================
   CoolChain FM — Work & vehicle monitoring, dashboard access
   assets/js/09-monitoring.js

   Who is free, who is working and on what; fleet deployment; access control.
   ===================================================================== */

function vMon(){
  const fu=fieldUsers();
  const free=fu.filter(u=>uStatus(u.id)==='Available');
  const busy=fu.filter(u=>['Working','Assigned'].includes(uStatus(u.id)));
  const off=fu.filter(u=>['On Leave','Inactive'].includes(uStatus(u.id)));
  later(startTickers);
  return `<div class="stat-grid" style="margin-bottom:18px">
    ${statCard('Available crew',free.length,'Ready to dispatch','c')}
    ${statCard('Working now',fu.filter(u=>uStatus(u.id)==='Working').length,'On site','w')}
    ${statCard('Assigned',fu.filter(u=>uStatus(u.id)==='Assigned').length,'Allocated, not started','v')}
    ${statCard('Unavailable',off.length,'On leave or inactive')}
  </div>
  <div class="sec-h"><h2>Working users</h2><span class="rule"></span><span class="eyebrow">${busy.length} engaged</span></div>
  <div class="card"><div class="tbl-wrap"><table>
    <thead><tr><th>Employee</th><th>Role</th><th>Current SR</th><th>Client</th><th>Location</th><th>Vehicle</th><th>Start time</th><th>Current duration</th><th>Status</th><th></th></tr></thead>
    <tbody>${busy.length?busy.map(u=>{const c=curSR(u.id);return `<tr>
      <td><div class="who">${av(u.name)}<div><b>${esc(u.name)}</b><small>${esc(u.empId)}</small></div></div></td>
      <td>${esc(u.role)}</td>
      <td><span class="sr-no">#${c.srNo}</span></td>
      <td>${esc(c.client)}<div style="color:var(--txt-3);font-size:11.5px">${esc(c.serviceType)}</div></td>
      <td>${esc(c.area)}, ${esc(c.emirates)}<div style="color:var(--txt-3);font-size:11.5px">${esc(c.location||'')}</div></td>
      <td class="mono">${c.vehId?esc(veh(c.vehId).reg):'—'}</td>
      <td class="mono">${c.timeIn?fmtTime(c.timeIn):'Not started'}</td>
      <td>${c.timeIn?`<span class="live" data-tick="${c.timeIn}"></span>`:'—'}</td>
      <td>${bdg(uStatus(u.id))}</td>
      <td><button class="btn btn-sm" onclick="viewSR('${c.srNo}')">Open SR</button></td></tr>`}).join('')
      :`<tr><td colspan="10" class="t-empty"><b>Everybody is free</b>No crew is currently engaged on a service request.</td></tr>`}</tbody>
  </table></div></div>

  <div class="sec-h"><h2>Available users</h2><span class="rule"></span><span class="eyebrow">${free.length} ready</span></div>
  <div class="mini-cards">${free.length?free.map(u=>`<div class="mini">
      <div class="mini-h">${av(u.name,34)}<div><b style="font-family:Archivo">${esc(u.name)}</b><div class="eyebrow">${esc(u.role)}</div></div>
        <span style="margin-left:auto">${bdg('Available')}</span></div>
      <dl class="kv"><dt>Emp ID</dt><dd class="mono">${esc(u.empId)}</dd>
        <dt>Base</dt><dd>${esc(u.destination)}, ${esc(u.emirates)}</dd>
        <dt>Vehicle</dt><dd class="mono">${u.vehId?esc(veh(u.vehId).reg):'—'}</dd>
        <dt>Jobs done</dt><dd>${historyOf(u.id).length}</dd></dl>
    </div>`).join('')
    :`<div class="card"><div class="t-empty"><b>Nobody free</b>Every field employee is on a request or unavailable.</div></div>`}</div>

  ${off.length?`<div class="sec-h"><h2>Unavailable</h2><span class="rule"></span></div>
  <div class="card"><div class="tbl-wrap"><table><thead><tr><th>Employee</th><th>Role</th><th>Base</th><th>Status</th></tr></thead>
    <tbody>${off.map(u=>`<tr><td><div class="who">${av(u.name)}<b>${esc(u.name)}</b></div></td><td>${esc(u.role)}</td><td>${esc(u.destination)}</td><td>${bdg(uStatus(u.id))}</td></tr>`).join('')}</tbody>
  </table></div></div>`:''}`;
}

function vVehMon(){
  const g=s=>S.vehicles.filter(v=>vStatus(v.id)===s);
  later(startTickers);
  const grp=(title,list,note)=>`<div class="sec-h"><h2>${title}</h2><span class="rule"></span><span class="eyebrow">${list.length}</span></div>
    ${list.length?`<div class="card"><div class="tbl-wrap"><table>
      <thead><tr><th>Registration</th><th>Type</th><th>Current SR</th><th>Client</th><th>Driver</th><th>Supervisor</th><th>Location</th><th>Start time</th><th>Duration</th><th>Status</th></tr></thead>
      <tbody>${list.map(v=>{const c=curSRVeh(v.id);return `<tr>
        <td><b class="mono">${esc(v.reg)}</b></td><td>${esc(v.type)}</td>
        <td>${c?`<span class="sr-no">#${c.srNo}</span>`:'—'}</td>
        <td>${c?esc(c.client):'—'}</td>
        <td>${v.driverId?esc(user(v.driverId).name):'—'}</td>
        <td>${v.supId?esc(user(v.supId).name):'—'}</td>
        <td>${c?esc(c.area+', '+c.emirates):esc(v.location)}</td>
        <td class="mono">${c&&c.timeIn?fmtTime(c.timeIn):'—'}</td>
        <td>${c&&c.timeIn?`<span class="live" data-tick="${c.timeIn}"></span>`:'—'}</td>
        <td>${bdg(vStatus(v.id))}</td></tr>`}).join('')}</tbody></table></div></div>`
    :`<div class="card"><div class="t-empty">${esc(note)}</div></div>`}`;
  return `<div class="stat-grid" style="margin-bottom:6px">
      ${statCard('Available',g('Available').length,'Parked and ready','c')}
      ${statCard('Assigned',g('Assigned').length,'Allocated to a request','v')}
      ${statCard('In service',g('In Service').length,'Out on a job','w')}
      ${statCard('Maintenance',g('Maintenance').length,'Off road','h')}
      ${statCard('Inactive',g('Inactive').length,'Not in the roster')}
    </div>
    ${grp('Vehicles in service',g('In Service'),'No van is on a running job.')}
    ${grp('Assigned vehicles',g('Assigned'),'Nothing allocated yet.')}
    ${grp('Available vehicles',g('Available'),'Every van is deployed.')}
    ${grp('Under maintenance',g('Maintenance'),'No vehicle is at the workshop.')}`;
}

/* =====================================================================
   DASHBOARD ACCESS
   ===================================================================== */
function vAccess(){
  return `<div class="card">
    <div class="card-h"><div><h3>Dashboard access users</h3><div class="eyebrow" style="margin-top:2px">Who can open the operations dashboard</div></div>
      <button class="btn btn-sm btn-cool" onclick="openAccess()">${icon('plus',14)} Grant access</button></div>
    <div class="tbl-wrap"><table>
      <thead><tr><th>User</th><th>Role</th><th>Email</th><th>Access scope</th><th>Status</th><th>Last login</th><th>Actions</th></tr></thead>
      <tbody>${S.dashAccess.length?S.dashAccess.map(a=>{const u=user(a.userId)||{name:'Unknown',role:'—',email:'—'};return `<tr>
        <td><div class="who">${av(u.name)}<div><b>${esc(u.name)}</b><small>${esc(u.empId||'')}</small></div></div></td>
        <td>${esc(u.role)}</td><td style="font-size:12.5px">${esc(u.email)}</td>
        <td>${esc(a.scope)}</td>
        <td><div style="display:flex;align-items:center;gap:9px">
          <button class="switch ${a.enabled?'on':''}" role="switch" aria-checked="${a.enabled}" onclick="toggleAccess('${a.id}')"></button>
          <span style="font-size:12.5px;color:var(--txt-2)">${a.enabled?'Enabled':'Disabled'}</span></div></td>
        <td class="mono" style="font-size:11.5px">${fmtDT(a.lastLogin)}</td>
        <td><button class="btn btn-sm btn-danger" onclick="revokeAccess('${a.id}')">Remove</button></td></tr>`}).join('')
        :`<tr><td colspan="7" class="t-empty"><b>No dashboard access granted</b>Grant access so managers can monitor operations.</td></tr>`}</tbody>
    </table></div></div>`;
}
function toggleAccess(id){const a=S.dashAccess.find(x=>x.id===id);a.enabled=!a.enabled;save();render();
  toast(a.enabled?'Access enabled':'Access disabled',(user(a.userId)||{}).name+' — '+a.scope,'warn')}
function revokeAccess(id){const a=S.dashAccess.find(x=>x.id===id);const n=(user(a.userId)||{}).name;
  confirmBox('Remove dashboard access?',n+' will no longer be able to open the dashboard.','Remove access','btn-danger',()=>{
    S.dashAccess=S.dashAccess.filter(x=>x.id!==id);save();closeModal();render();toast('Access removed',n+' can no longer sign in to the dashboard.','warn')})}
function openAccess(){
  let pick={userId:'',scope:'Reports only'};
  const avail=S.users.filter(u=>!S.dashAccess.some(a=>a.userId===u.id));
  modal({title:'Grant dashboard access',eyebrow:'Access control',slim:true,
    body:`<div class="field"><label>User</label><select class="inp" id="acU">${opts(avail.map(u=>({v:u.id,l:u.name+' — '+u.role})),'','Select user')}</select></div>
      <div class="field"><label>Access scope</label><select class="inp" id="acS">${opts(['Full dashboard','Operations + reports','Reports only','Own team only'],'Reports only','Select')}</select></div>`,
    footer:`<button class="btn l" onclick="closeModal()">Cancel</button><button class="btn btn-cool" onclick="saveAccess()">Grant access</button>`});
}
function saveAccess(){
  const uId=$('#acU').value,scope=$('#acS').value;
  if(!uId){toast('Select a user','Choose who should get dashboard access.','err');return}
  S.dashAccess.push({id:uid('DA'),userId:uId,scope,enabled:true,lastLogin:null});
  save();closeModal();render();toast('Access granted',user(uId).name+' — '+scope,'ok');
}
