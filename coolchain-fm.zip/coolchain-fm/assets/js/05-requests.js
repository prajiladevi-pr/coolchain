/* =====================================================================
   CoolChain FM — Service requests / complaints
   assets/js/05-requests.js

   Filters, listing, create and edit form with multiple service items,
   allocation, start work, complete work, close and cancel.
   ===================================================================== */

const F={sr:{q:'',status:'',client:'',area:'',em:'',amc:'',prio:'',type:'',sup:'',veh:'',from:'',to:''},
         us:{q:'',role:'',status:'',em:''},
         vh:{q:'',status:'',type:'',loc:''}};
function setF(g,k,v){F[g][k]=v;render()}
function clearF(g){Object.keys(F[g]).forEach(k=>F[g][k]='');render()}
const opts=(list,sel,ph)=>`<option value="">${ph}</option>`+list.map(o=>{
  const v=typeof o==='string'?o:o.v,l=typeof o==='string'?o:o.l;
  return `<option value="${esc(v)}"${sel===v?' selected':''}>${esc(l)}</option>`}).join('');

function filterSR(){
  const f=F.sr,q=f.q.toLowerCase();
  return S.requests.filter(r=>{
    if(f.status&&r.status!==f.status)return false;
    if(f.client&&r.client!==f.client)return false;
    if(f.area&&r.area!==f.area)return false;
    if(f.em&&r.emirates!==f.em)return false;
    if(f.amc&&r.amc!==f.amc)return false;
    if(f.prio&&r.priority!==f.prio)return false;
    if(f.type&&r.serviceType!==f.type)return false;
    if(f.sup&&r.supId!==f.sup)return false;
    if(f.veh&&r.vehId!==f.veh)return false;
    if(f.from&&r.reportedDate<new Date(f.from).setHours(0,0,0,0))return false;
    if(f.to&&r.reportedDate>new Date(f.to).setHours(23,59,59,999))return false;
    if(q){
      const hay=[r.srNo,r.projectNo,r.client,r.area,r.location,r.emirates,r.serviceType,r.equipment,r.description,r.remarks,
        ...teamNames(r),r.vehId?veh(r.vehId).reg:''].join(' ').toLowerCase();
      if(!hay.includes(q))return false;
    }
    return true;
  }).sort((a,b)=>b.reportedDate-a.reportedDate);
}

/* =====================================================================
   SERVICE REQUESTS
   ===================================================================== */
function vRequests(){
  const list=filterSR(),f=F.sr;
  const n=s=>S.requests.filter(r=>r.status===s).length;
  later(startTickers);
  return `
  <div class="card">
    <div class="bar-tools">
      <div class="search">${icon('search',15)}<input class="inp" placeholder="Search SR no, client, location, crew, van…" value="${esc(f.q)}" oninput="F.sr.q=this.value;renderSRTable()"></div>
      <select class="inp" onchange="setF('sr','status',this.value)">${opts(SRSTATUS,f.status,'All statuses')}</select>
      <select class="inp" onchange="setF('sr','client',this.value)">${opts(CLIENTS,f.client,'All clients')}</select>
      <select class="inp" onchange="setF('sr','area',this.value)">${opts(AREAS,f.area,'All areas')}</select>
      <select class="inp" onchange="setF('sr','em',this.value)">${opts(EMIRATES,f.em,'All emirates')}</select>
      <select class="inp" onchange="setF('sr','amc',this.value)">${opts(['AMC','Non-AMC'],f.amc,'AMC / Non-AMC')}</select>
      <select class="inp" onchange="setF('sr','prio',this.value)">${opts(PRIOS,f.prio,'All priorities')}</select>
      <select class="inp" onchange="setF('sr','type',this.value)">${opts(STYPES,f.type,'All service types')}</select>
      <select class="inp" onchange="setF('sr','sup',this.value)">${opts(S.users.filter(u=>u.role==='Supervisor').map(u=>({v:u.id,l:u.name})),f.sup,'All supervisors')}</select>
      <select class="inp" onchange="setF('sr','veh',this.value)">${opts(S.vehicles.map(v=>({v:v.id,l:v.reg})),f.veh,'All vehicles')}</select>
      <input class="inp" type="date" value="${f.from}" title="From date" onchange="setF('sr','from',this.value)">
      <input class="inp" type="date" value="${f.to}" title="To date" onchange="setF('sr','to',this.value)">
      <button class="btn btn-sm" onclick="clearF('sr')">Clear</button>
      <button class="btn btn-sm btn-cool" style="margin-left:auto" onclick="openSR()">${icon('plus',14)} Add service request</button>
    </div>
    <div class="bar-tools" style="border-bottom:1px solid var(--line)">
      <div class="chips">
        <button class="chip ${!f.status?'on':''}" onclick="setF('sr','status','')">All<span class="n">${S.requests.length}</span></button>
        ${SRSTATUS.map(s=>`<button class="chip ${f.status===s?'on':''}" onclick="setF('sr','status','${s}')">${s}<span class="n">${n(s)}</span></button>`).join('')}
      </div>
      <span class="eyebrow" style="margin-left:auto">${list.length} shown</span>
    </div>
    <div id="srTable">${srTable(list)}</div>
  </div>`;
}
function renderSRTable(){$('#srTable').innerHTML=srTable(filterSR());startTickers()}
function srTable(list){
  if(!list.length)return `<div class="t-empty">${emptyArt('')}<b>No service requests match</b>Adjust the filters, or register a new request.</div>`;
  return `<div class="tbl-wrap"><table>
  <thead><tr><th>SR No</th><th>Project</th><th>Date</th><th>Client</th><th>Area</th><th>Emirates</th><th>Service type</th><th>Priority</th><th>Contract</th><th>Supervisor</th><th>Vehicle</th><th>Status</th><th>Actions</th></tr></thead>
  <tbody>${list.map(r=>`<tr>
    <td><span class="sr-no">#${r.srNo}</span>${r.items.length>1?`<div class="eyebrow" style="margin-top:3px">${r.items.length} items</div>`:''}</td>
    <td class="mono" style="font-size:11.5px;color:var(--txt-2)">${esc(r.projectNo||'—')}</td>
    <td class="mono" style="font-size:11.5px">${fmtDate(r.reportedDate)}</td>
    <td><b>${esc(r.client)}</b></td>
    <td>${esc(r.area)}</td><td>${esc(r.emirates)}</td>
    <td>${esc(r.serviceType)}<div style="color:var(--txt-3);font-size:11.5px">${esc(r.equipment)}</div></td>
    <td>${bdg(r.priority,1)}</td><td>${bdg(r.amc,1)}</td>
    <td>${sup(r)?`<div class="who">${av(sup(r).name,26)}<div><b>${esc(sup(r).name)}</b><small>${(r.techIds||[]).length} tech</small></div></div>`:'<span style="color:var(--txt-3)">—</span>'}</td>
    <td class="mono">${r.vehId?esc(veh(r.vehId).reg):'—'}</td>
    <td>${bdg(r.status)}${r.timeIn&&r.status==='Work Started'?`<div class="live" style="font-size:11px" data-tick="${r.timeIn}"></div>`:''}</td>
    <td><div class="acts">
      <button class="btn btn-icon" title="View" onclick="viewSR('${r.srNo}')">${icon('eye',14)}</button>
      <button class="btn btn-icon" title="Edit" onclick="openSR('${r.srNo}')">${icon('pen',14)}</button>
      ${r.status==='New'?`<button class="btn btn-sm btn-cool" onclick="openAllocate('${r.srNo}')">Allocate</button>`:''}
      ${r.status==='Allocated'?`<button class="btn btn-sm btn-warm" onclick="startWork('${r.srNo}','admin')">Start</button>`:''}
      ${r.status==='Work Started'?`<button class="btn btn-sm btn-done" onclick="openComplete('${r.srNo}','admin')">Complete</button>`:''}
      ${r.status==='Work Completed'?`<button class="btn btn-sm" onclick="closeSR('${r.srNo}')">Close</button>`:''}
    </div></td></tr>`).join('')}</tbody></table></div>`;
}

/* ---------- SR create / edit ---------- */
let draft=null;
function openSR(srNo){
  const r=srNo?sr(srNo):null;
  draft=r?JSON.parse(JSON.stringify(r)):{
    srNo:'',projectNo:'',client:'',area:'',location:'',emirates:'Dubai',serviceType:'AC Checking',amc:'AMC',
    priority:'Medium',equipment:'Ductable AC',description:'',items:[{floor:'',equipment:'Ductable AC',work:'',qty:1}],
    reportedDate:now(),expectedFix:daysAgo(-1),scheduledDate:now(),status:'New',
    supId:null,techIds:[],driverId:null,vehId:null,timeIn:null,timeOut:null,hours:null,
    workPerformed:'',remarks:'',notes:'',material:'',replacement:'No',followUp:'No',timeline:[]
  };
  draft.__edit=!!r;
  modal({title:draft.__edit?'Edit service request #'+r.srNo:'Register service request',eyebrow:draft.__edit?'Service request':'New complaint / service request',wide:true,
    body:srForm(),
    footer:`<button class="btn l btn-danger" onclick="closeModal()">Discard</button>
            <button class="btn" onclick="closeModal()">Cancel</button>
            <button class="btn btn-cool" onclick="saveSR()">${draft.__edit?'Save changes':'Save request'}</button>`});
}
const dset=(k,v)=>{draft[k]=v};
function srForm(){
  const d=draft;
  const dstr=ts=>{const x=new Date(ts||now());return `${x.getFullYear()}-${pad(x.getMonth()+1)}-${pad(x.getDate())}`};
  return `
  <div class="panel-t">Identification</div>
  <div class="grid3">
    <div class="field"><label>SR number</label><input class="inp mono" value="${esc(d.srNo)}" placeholder="Auto on save" oninput="dset('srNo',this.value)"></div>
    <div class="field"><label>Project number</label><input class="inp mono" value="${esc(d.projectNo)}" placeholder="Optional" oninput="dset('projectNo',this.value)"></div>
    <div class="field"><label>Service date</label><input class="inp" type="date" value="${dstr(d.reportedDate)}" onchange="dset('reportedDate',new Date(this.value+'T09:00').getTime())"></div>
  </div>
  <div class="panel-t" style="margin-top:8px">Client</div>
  <div class="grid2">
    <div class="field"><label>Client name</label><input class="inp" list="dlClients" value="${esc(d.client)}" placeholder="Nesto Hypermarket" oninput="dset('client',this.value)">
      <datalist id="dlClients">${CLIENTS.map(c=>`<option value="${esc(c)}">`).join('')}</datalist></div>
    <div class="field"><label>Area</label><input class="inp" list="dlAreas" value="${esc(d.area)}" placeholder="Nad Al Hamar" oninput="dset('area',this.value)">
      <datalist id="dlAreas">${AREAS.map(c=>`<option value="${esc(c)}">`).join('')}</datalist></div>
  </div>
  <div class="grid2">
    <div class="field"><label>Location on site</label><input class="inp" value="${esc(d.location)}" placeholder="Ground floor, customer service side" oninput="dset('location',this.value)"></div>
    <div class="field"><label>Emirates</label><select class="inp" onchange="dset('emirates',this.value)">${opts(EMIRATES,d.emirates,'Select')}</select></div>
  </div>
  <div class="panel-t" style="margin-top:8px">Classification</div>
  <div class="grid3">
    <div class="field"><label>Service type</label><select class="inp" onchange="dset('serviceType',this.value)">${opts(STYPES,d.serviceType,'Select')}</select></div>
    <div class="field"><label>Contract type</label><select class="inp" onchange="dset('amc',this.value)">${opts(['AMC','Non-AMC'],d.amc,'Select')}</select></div>
    <div class="field"><label>Priority</label><select class="inp" onchange="dset('priority',this.value)">${opts(PRIOS,d.priority,'Select')}</select></div>
  </div>
  <div class="grid3">
    <div class="field"><label>Primary equipment</label><select class="inp" onchange="dset('equipment',this.value)">${opts(EQUIP,d.equipment,'Select')}</select></div>
    <div class="field"><label>Expected fix by</label><input class="inp" type="date" value="${dstr(d.expectedFix)}" onchange="dset('expectedFix',new Date(this.value+'T18:00').getTime())"></div>
    <div class="field"><label>Scheduled visit</label><input class="inp" type="date" value="${dstr(d.scheduledDate)}" onchange="dset('scheduledDate',new Date(this.value+'T09:00').getTime())"></div>
  </div>
  <div class="field"><label>Service description</label>
    <textarea class="inp" placeholder="Ground floor G-19 ductable AC indoor fan motor removed and blower motor cleaning. Need water service." oninput="dset('description',this.value)">${esc(d.description)}</textarea></div>

  <div class="panel-t" style="margin-top:8px">Service items — one request can carry several activities</div>
  <div class="card" style="box-shadow:none;margin-bottom:14px"><div class="tbl-wrap"><table class="items-tbl">
    <thead><tr><th style="width:34px">#</th><th>Floor / area</th><th>Equipment</th><th>Problem / work required</th><th style="width:78px">Qty</th><th style="width:40px"></th></tr></thead>
    <tbody id="itemRows">${itemRows()}</tbody></table></div>
    <div style="padding:10px 12px"><button class="btn btn-sm" onclick="addItem()">${icon('plus',13)} Add service item</button></div>
  </div>

  <div class="panel-t">Team &amp; vehicle assignment — leave blank to allocate later</div>
  ${assignBlock()}`;
}
function itemRows(){
  return draft.items.map((it,i)=>`<tr>
    <td class="mono" style="color:var(--txt-3)">${i+1}</td>
    <td><input value="${esc(it.floor)}" placeholder="Ground Floor G-19" oninput="draft.items[${i}].floor=this.value"></td>
    <td><select onchange="draft.items[${i}].equipment=this.value">${opts(EQUIP,it.equipment,'Select')}</select></td>
    <td><input value="${esc(it.work)}" placeholder="Fan motor / blower cleaning" oninput="draft.items[${i}].work=this.value"></td>
    <td><input type="number" min="1" value="${it.qty}" oninput="draft.items[${i}].qty=Number(this.value)||1"></td>
    <td>${draft.items.length>1?`<button class="btn btn-icon btn-danger" onclick="delItem(${i})">${icon('trash',13)}</button>`:''}</td></tr>`).join('');
}
function addItem(){draft.items.push({floor:'',equipment:draft.equipment,work:'',qty:1});$('#itemRows').innerHTML=itemRows()}
function delItem(i){draft.items.splice(i,1);$('#itemRows').innerHTML=itemRows()}

function assignBlock(){
  const d=draft;
  const supList=S.users.filter(u=>u.role==='Supervisor');
  const techList=S.users.filter(u=>u.role==='Technical Staff');
  const drvList=S.users.filter(u=>u.role==='Driver');
  const dot=s=>({'Available':'🟢','Working':'🟠','Assigned':'🔵','On Leave':'⚪','Inactive':'⚪','In Service':'🔴','Maintenance':'🔴'}[s]||'⚪');
  const uOpt=(list,sel,ph)=>`<option value="">${ph}</option>`+list.map(u=>{
    const st=uStatus(u.id);const bad=['Inactive'].includes(st);
    return `<option value="${u.id}"${sel===u.id?' selected':''}${bad?' disabled':''}>${dot(st)} ${esc(u.name)} — ${st}</option>`}).join('');
  const vOpt=`<option value="">Select vehicle</option>`+S.vehicles.map(v=>{
    const st=vStatus(v.id);const bad=['Maintenance','Inactive'].includes(st);
    return `<option value="${v.id}"${d.vehId===v.id?' selected':''}${bad?' disabled':''}>${dot(st)} ${esc(v.reg)} — ${st}</option>`}).join('');
  return `<div class="grid2">
    <div class="field"><label>Supervisor</label><select class="inp" onchange="dset('supId',this.value||null)">${uOpt(supList,d.supId,'Select supervisor')}</select></div>
    <div class="field"><label>Driver</label><select class="inp" onchange="dset('driverId',this.value||null)">${uOpt(drvList,d.driverId,'Select driver')}</select></div>
  </div>
  <div class="grid3">
    <div class="field"><label>Technical staff 1</label><select class="inp" onchange="setTech(0,this.value)">${uOpt(techList,d.techIds[0],'Select technician')}</select></div>
    <div class="field"><label>Technical staff 2 <span style="text-transform:none;letter-spacing:0;color:var(--txt-3)">(optional)</span></label><select class="inp" onchange="setTech(1,this.value)">${uOpt(techList,d.techIds[1],'Select technician')}</select></div>
    <div class="field"><label>Vehicle</label><select class="inp" onchange="dset('vehId',this.value||null)">${vOpt}</select></div>
  </div>
  <div class="panel"><div class="panel-t">Resource availability right now</div>
    <div class="grid3" style="gap:14px">
      <div><div class="eyebrow" style="margin-bottom:7px">Supervisors</div>${supList.map(u=>resRow(u)).join('')}</div>
      <div><div class="eyebrow" style="margin-bottom:7px">Technical staff</div>${techList.map(u=>resRow(u)).join('')}</div>
      <div><div class="eyebrow" style="margin-bottom:7px">Vehicles</div>${S.vehicles.map(v=>`<div class="res ${draft.vehId===v.id?'pick':''}"><span class="mono">${esc(v.reg)}</span><span class="st">${bdg(vStatus(v.id))}</span></div>`).join('')}</div>
    </div></div>`;
}
function resRow(u){const picked=draft.supId===u.id||draft.techIds.includes(u.id)||draft.driverId===u.id;
  return `<div class="res ${picked?'pick':''}">${av(u.name,22)}<span>${esc(u.name)}</span><span class="st">${bdg(uStatus(u.id))}</span></div>`}
function setTech(i,v){draft.techIds=draft.techIds.slice();if(v)draft.techIds[i]=v;else draft.techIds[i]=null;draft.techIds=draft.techIds.filter(Boolean);
  const seen=new Set();draft.techIds=draft.techIds.filter(x=>!seen.has(x)&&seen.add(x))}

function saveSR(){
  const d=draft;
  if(!d.client.trim()){toast('Client required','Enter the client name before saving.','err');return}
  if(!d.area.trim()){toast('Area required','Enter the area so the crew knows where to go.','err');return}
  if(!d.items.some(i=>i.work.trim())&&!d.description.trim()){toast('Describe the work','Add at least one service item or a description.','err');return}
  d.items=d.items.filter(i=>i.work.trim()||i.floor.trim());
  if(!d.items.length)d.items=[{floor:d.location||d.area,equipment:d.equipment,work:d.serviceType,qty:1}];
  const editing=d.__edit;delete d.__edit;
  if(!d.srNo.trim())d.srNo=nextSR();
  const hadTeam=d.supId&&d.vehId;
  if(!editing){
    d.timeline=[{t:now(),e:'Service request registered',by:'System Administrator'}];
    d.status='New';
    S.requests.unshift(d);
    notify('admin','Service request registered',`SR #${d.srNo} · ${d.client}, ${d.area} — ${d.serviceType}.`,null,now(),d.srNo);
    toast('Service request saved','SR #'+d.srNo+' created with status NEW.','ok');
    closeModal();render();
    if(hadTeam)setTimeout(()=>openAllocate(d.srNo),350);
  }else{
    const i=S.requests.findIndex(r=>r.srNo===d.srNo);
    if(i>-1)S.requests[i]=d;else S.requests.unshift(d);
    d.timeline.push({t:now(),e:'Service request updated',by:'System Administrator'});
    toast('Changes saved','SR #'+d.srNo+' updated.','ok');
    closeModal();render();
  }
}

/* ---------- allocation ---------- */
function openAllocate(srNo){
  const r=sr(srNo);if(!r)return;
  draft=JSON.parse(JSON.stringify(r));draft.__edit=true;
  modal({title:'Allocate SR #'+r.srNo,eyebrow:`${r.client} · ${r.area}, ${r.emirates}`,wide:true,
    body:`<div class="panel" style="margin-bottom:16px"><div class="grid2" style="gap:14px">
        <div><div class="panel-t">Work required</div><div style="font-size:13px">${esc(r.description||'—')}</div></div>
        <div><div class="panel-t">Classification</div>${bdg(r.serviceType,1)} ${bdg(r.amc,1)} ${bdg(r.priority,1)}
          <div style="margin-top:8px;font-size:12.5px;color:var(--txt-2)">Fix by ${fmtDate(r.expectedFix)} · ${r.items.length} service item${r.items.length>1?'s':''}</div></div>
      </div></div>${assignBlock()}`,
    footer:`<button class="btn l" onclick="closeModal()">Cancel</button>
            <button class="btn btn-cool" onclick="doAllocate('${r.srNo}')">${icon('send',14)} Allocate &amp; notify supervisor</button>`});
}
function doAllocate(srNo){
  const r=sr(srNo),d=draft;
  if(!d.supId){toast('Supervisor required','A supervisor must own the job before it can be allocated.','err');return}
  if(!d.techIds.filter(Boolean).length){toast('Technician required','Assign at least one technical staff member.','err');return}
  if(!d.vehId){toast('Vehicle required','Assign a service vehicle.','err');return}
  Object.assign(r,{supId:d.supId,techIds:d.techIds.filter(Boolean),driverId:d.driverId,vehId:d.vehId,status:'Allocated'});
  r.timeline.push({t:now(),e:'Allocated to '+user(r.supId).name,by:'System Administrator'});
  r.timeline.push({t:now()+1,e:'Assignment notification sent to supervisor',by:'System'});
  notify('supervisor','New service request assigned',
    `SR #${r.srNo} · ${r.client}\n${r.area}, ${r.emirates}\n${r.equipment} — ${r.serviceType}\nPriority: ${r.priority}\nFix by: ${fmtDate(r.expectedFix)}`,r.supId,now(),r.srNo);
  closeModal();afterAction();
  toast('Allocated','SR #'+r.srNo+' sent to '+user(r.supId).name+' · vehicle '+veh(r.vehId).reg,'ok');
  setTimeout(()=>toast('Supervisor notified','Open the supervisor app to start the work.','warn'),900);
}

/* ---------- workflow actions ---------- */
function startWork(srNo,from){
  const r=sr(srNo);if(!r)return;
  confirmBox('Start work on SR #'+r.srNo+'?',
    `Time in will be recorded now. ${teamNames(r).join(', ')} will move to Working and ${r.vehId?veh(r.vehId).reg:'the vehicle'} to In Service.`,
    'Start work','btn-warm',()=>{
      r.status='Work Started';r.timeIn=now();
      r.timeline.push({t:r.timeIn,e:'Work started on site',by:user(r.supId).name});
      notify('admin','Work started',`SR #${r.srNo} · ${r.client} — ${user(r.supId).name} started on site.`,null,now(),r.srNo);
      save();closeModal();
      if(from==='sup')phSheet=null;
      afterAction();
      toast('Work started','Time in '+fmtTime(r.timeIn)+' · crew and vehicle now shown as engaged.','warn');
    });
}
let cdraft={};
function openComplete(srNo,from){
  const r=sr(srNo);if(!r)return;
  cdraft={workPerformed:'',remarks:'',notes:'',material:'',replacement:'No',followUp:'No',from};
  modal({title:'Complete work — SR #'+r.srNo,eyebrow:`${r.client} · ${r.area}`,
    body:`<div class="panel" style="margin-bottom:16px;display:flex;gap:22px;flex-wrap:wrap">
      <div><div class="panel-t">Time in</div><b class="mono">${fmtTime(r.timeIn)}</b></div>
      <div><div class="panel-t">Elapsed</div><b class="live mono" data-tick="${r.timeIn}">${dur(now()-r.timeIn)}</b></div>
      <div><div class="panel-t">Crew</div><b>${esc(teamNames(r).join(', '))}</b></div>
      <div><div class="panel-t">Vehicle</div><b class="mono">${r.vehId?esc(veh(r.vehId).reg):'—'}</b></div></div>
      <div class="field"><label>Work performed</label><textarea class="inp" placeholder="Gas charging completed." oninput="cdraft.workPerformed=this.value"></textarea></div>
      <div class="field"><label>Completion remarks</label><textarea class="inp" placeholder="AC checked and gas charged successfully." oninput="cdraft.remarks=this.value"></textarea></div>
      <div class="field"><label>Additional notes</label><input class="inp" placeholder="Optional" oninput="cdraft.notes=this.value"></div>
      <div class="grid3">
        <div class="field"><label>Material used</label><input class="inp" placeholder="R410a 2 kg" oninput="cdraft.material=this.value"></div>
        <div class="field"><label>Replacement required</label><select class="inp" onchange="cdraft.replacement=this.value"><option>No</option><option>Yes</option></select></div>
        <div class="field"><label>Follow-up required</label><select class="inp" onchange="cdraft.followUp=this.value"><option>No</option><option>Yes</option></select></div>
      </div>`,
    footer:`<button class="btn l" onclick="closeModal()">Cancel</button>
            <button class="btn btn-done" onclick="doComplete('${r.srNo}')">${icon('check',14)} Complete work</button>`});
  later(startTickers);startTickers();
}
function doComplete(srNo){
  const r=sr(srNo);
  if(!cdraft.workPerformed.trim()){toast('Work performed required','Record what was done on site.','err');return}
  r.timeOut=now();r.hours=hoursOf(r.timeIn,r.timeOut);r.status='Work Completed';
  Object.assign(r,{workPerformed:cdraft.workPerformed,remarks:cdraft.remarks,notes:cdraft.notes,material:cdraft.material,replacement:cdraft.replacement,followUp:cdraft.followUp});
  r.timeline.push({t:r.timeOut,e:'Work completed',by:user(r.supId).name});
  notify('admin','Work completed',`SR #${r.srNo} · ${r.client} — ${r.hours} h recorded by ${user(r.supId).name}.`,null,now(),r.srNo);
  if(cdraft.followUp==='Yes')notify('admin','Follow-up flagged',`SR #${r.srNo} · ${r.client} — supervisor marked follow-up required.`,null,now(),r.srNo);
  const from=cdraft.from;save();closeModal();
  phSheet=null;if(from==='sup')phTab='completed';
  afterAction();
  toast('Service request completed','Time out '+fmtTime(r.timeOut)+' · '+r.hours+' h. Crew and vehicle released.','ok');
}
function closeSR(srNo){
  const r=sr(srNo);
  confirmBox('Close SR #'+r.srNo+'?','The request has been completed on site. Closing files it into reporting and work history.','Close request','btn-p',()=>{
    r.status='Closed';r.timeline.push({t:now(),e:'Reviewed and closed',by:'System Administrator'});
    save();closeModal();phSheet=null;afterAction();toast('Request closed','SR #'+r.srNo+' filed to history.','ok');
  });
}
function cancelSR(srNo){
  const r=sr(srNo);
  confirmBox('Cancel SR #'+r.srNo+'?','The crew and vehicle are released and the request is marked cancelled.','Cancel request','btn-danger',()=>{
    r.status='Cancelled';r.timeline.push({t:now(),e:'Cancelled',by:'System Administrator'});
    save();closeModal();phSheet=null;afterAction();toast('Request cancelled','SR #'+r.srNo+' will not be dispatched.','warn');
  });
}
