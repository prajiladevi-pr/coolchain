/* =====================================================================
   CoolChain FM — User management
   assets/js/07-users.js

   Listing, add and edit user, activate/deactivate, profile and work history.
   ===================================================================== */

function filterUsers(){
  const f=F.us,q=f.q.toLowerCase();
  return S.users.filter(u=>{
    if(f.role&&u.role!==f.role)return false;
    if(f.em&&u.emirates!==f.em)return false;
    if(f.status&&uStatus(u.id)!==f.status)return false;
    if(q&&![u.name,u.empId,u.role,u.destination,u.emirates,u.mobile,u.email].join(' ').toLowerCase().includes(q))return false;
    return true;
  });
}
function vUsers(){
  const f=F.us,list=filterUsers();
  return `<div class="stat-grid" style="margin-bottom:18px">
    ${statCard('Total users',S.users.length,'All roles')}
    ${statCard('Supervisors',S.users.filter(u=>u.role==='Supervisor').length,'Job owners','v')}
    ${statCard('Technical staff',S.users.filter(u=>u.role==='Technical Staff').length,'Field technicians','c')}
    ${statCard('Drivers',S.users.filter(u=>u.role==='Driver').length,'Vehicle custodians')}
    ${statCard('Available now',fieldUsers().filter(u=>uStatus(u.id)==='Available').length,'Ready to dispatch','c')}
    ${statCard('Engaged now',fieldUsers().filter(u=>['Working','Assigned'].includes(uStatus(u.id))).length,'On active requests','w')}
  </div>
  <div class="card">
    <div class="bar-tools">
      <div class="search">${icon('search',15)}<input class="inp" placeholder="Search name, employee ID, mobile…" value="${esc(f.q)}" oninput="F.us.q=this.value;$('#uTable').innerHTML=uTable(filterUsers())"></div>
      <select class="inp" onchange="setF('us','role',this.value)">${opts(ROLES,f.role,'All roles')}</select>
      <select class="inp" onchange="setF('us','status',this.value)">${opts(USTATUS,f.status,'All statuses')}</select>
      <select class="inp" onchange="setF('us','em',this.value)">${opts(EMIRATES,f.em,'All emirates')}</select>
      <button class="btn btn-sm" onclick="clearF('us')">Clear</button>
      <button class="btn btn-sm btn-cool" style="margin-left:auto" onclick="openUser()">${icon('plus',14)} Add user</button>
    </div>
    <div id="uTable">${uTable(list)}</div>
  </div>`;
}
function uTable(list){
  if(!list.length)return `<div class="t-empty"><b>No users match</b>Try a different role or search term.</div>`;
  return `<div class="tbl-wrap"><table>
  <thead><tr><th>Employee</th><th>Employee ID</th><th>Role</th><th>Destination</th><th>Emirates</th><th>Current assignment</th><th>Vehicle</th><th>Status</th><th>History</th><th>Actions</th></tr></thead>
  <tbody>${list.map(u=>{
    const st=uStatus(u.id),c=curSR(u.id),h=historyOf(u.id);
    return `<tr>
    <td><div class="who">${av(u.name)}<div><b>${esc(u.name)}</b><small>${esc(u.mobile)}</small></div></div></td>
    <td class="mono">${esc(u.empId)}</td>
    <td>${esc(u.role)}</td><td>${esc(u.destination)}</td><td>${esc(u.emirates)}</td>
    <td>${c?`<span class="sr-no">#${c.srNo}</span> <span style="font-size:12px">${esc(c.client)}</span><div style="color:var(--txt-3);font-size:11.5px">${esc(c.area)} · ${esc(c.serviceType)}</div>`:'<span style="color:var(--txt-3)">—</span>'}</td>
    <td class="mono">${u.vehId?esc(veh(u.vehId).reg):'—'}</td>
    <td>${bdg(st)}</td>
    <td><button class="btn btn-icon" title="Work history" onclick="openHistory('${u.id}')" style="${h.length?'color:var(--warm);border-color:#F2DCBE;background:var(--warm-soft)':''}">${icon('hist',14)}</button>
        <span class="mono" style="font-size:11px;color:var(--txt-3);margin-left:4px">${h.length}</span></td>
    <td><div class="acts">
      <button class="btn btn-icon" title="View" onclick="viewUser('${u.id}')">${icon('eye',14)}</button>
      <button class="btn btn-icon" title="Edit" onclick="openUser('${u.id}')">${icon('pen',14)}</button>
      <button class="btn btn-sm" onclick="toggleUser('${u.id}')">${u.base==='Inactive'?'Activate':'Deactivate'}</button>
    </div></td></tr>`}).join('')}</tbody></table></div>`;
}
let udraft=null;
function openUser(id){
  const u=id?user(id):null;
  udraft=u?Object.assign({},u):{id:uid('U'),name:'',empId:'EMP-'+String(60+S.users.length).padStart(3,'0'),role:'Technical Staff',
    destination:'',emirates:'Dubai',mobile:'',email:'',address:'',joinDate:now(),base:'Available',supId:null,vehId:null};
  udraft.__edit=!!u;
  const dstr=ts=>{const x=new Date(ts||now());return `${x.getFullYear()}-${pad(x.getMonth()+1)}-${pad(x.getDate())}`};
  modal({title:u?'Edit '+u.name:'Add user',eyebrow:u?'Employee '+u.empId:'Workforce master data',
    body:`<div style="display:flex;gap:14px;align-items:center;margin-bottom:18px">
        <div id="upAv">${photoPreview(udraft.name)}</div>
        <div><div class="eyebrow">Profile photo</div>
          <button class="btn btn-sm" style="margin-top:6px" onclick="toast('Photo upload','In the production system this opens the device camera or file picker. The prototype uses generated initials.')">Upload photo</button></div>
      </div>
      <div class="grid2">
        <div class="field"><label>Full name</label><input class="inp" value="${esc(udraft.name)}" oninput="udraft.name=this.value;$('#upAv').innerHTML=photoPreview(this.value)"></div>
        <div class="field"><label>Employee ID</label><input class="inp mono" value="${esc(udraft.empId)}" oninput="udraft.empId=this.value"></div>
      </div>
      <div class="grid2">
        <div class="field"><label>Mobile number</label><input class="inp" value="${esc(udraft.mobile)}" placeholder="+971 5X XXX XXXX" oninput="udraft.mobile=this.value"></div>
        <div class="field"><label>Email</label><input class="inp" type="email" value="${esc(udraft.email)}" oninput="udraft.email=this.value"></div>
      </div>
      <div class="grid3">
        <div class="field"><label>Role</label><select class="inp" onchange="udraft.role=this.value;refreshUserForm()">${opts(ROLES,udraft.role,'Select')}</select></div>
        <div class="field"><label>Destination</label><input class="inp" list="dlAreas2" value="${esc(udraft.destination)}" oninput="udraft.destination=this.value">
          <datalist id="dlAreas2">${AREAS.concat(['Head Office']).map(a=>`<option value="${esc(a)}">`).join('')}</datalist></div>
        <div class="field"><label>Emirates</label><select class="inp" onchange="udraft.emirates=this.value">${opts(EMIRATES,udraft.emirates,'Select')}</select></div>
      </div>
      <div class="field"><label>Address</label><input class="inp" value="${esc(udraft.address)}" oninput="udraft.address=this.value"></div>
      <div class="grid3">
        <div class="field"><label>Joining date</label><input class="inp" type="date" value="${dstr(udraft.joinDate)}" onchange="udraft.joinDate=new Date(this.value).getTime()"></div>
        <div class="field"><label>Status</label><select class="inp" onchange="udraft.base=this.value">${opts(['Available','On Leave','Inactive'],udraft.base,'Select')}</select></div>
        <div class="field"><label>Assigned vehicle</label><select class="inp" onchange="udraft.vehId=this.value||null">${opts(S.vehicles.map(v=>({v:v.id,l:v.reg+' — '+v.type})),udraft.vehId,'None')}</select></div>
      </div>
      <div id="supField">${supFieldHTML()}</div>
      <p style="color:var(--txt-3);font-size:12.5px;margin:6px 0 0">Live status (Working / Assigned) is driven by active service requests, so it isn't set by hand here.</p>`,
    footer:`<button class="btn l" onclick="closeModal()">Cancel</button><button class="btn btn-cool" onclick="saveUser()">${u?'Save changes':'Add user'}</button>`});
}
function supFieldHTML(){
  if(!['Technical Staff','Driver'].includes(udraft.role))return '';
  return `<div class="field"><label>Assigned supervisor / team</label>
    <select class="inp" onchange="udraft.supId=this.value||null">${opts(S.users.filter(u=>u.role==='Supervisor').map(u=>({v:u.id,l:u.name+' — '+u.destination})),udraft.supId,'Unassigned')}</select></div>`;
}
function refreshUserForm(){$('#supField').innerHTML=supFieldHTML()}
function saveUser(){
  if(!udraft.name.trim()){toast('Name required','Enter the employee name.','err');return}
  const edit=udraft.__edit;delete udraft.__edit;
  if(!udraft.email)udraft.email=udraft.name.toLowerCase().replace(/[^a-z]+/g,'.')+'@coolchainfm.ae';
  if(edit){const i=S.users.findIndex(u=>u.id===udraft.id);S.users[i]=udraft;toast('User updated',udraft.name+' saved.','ok')}
  else{S.users.push(udraft);toast('User added',udraft.name+' · '+udraft.role+' · '+udraft.empId,'ok')}
  closeModal();render();
}
function toggleUser(id){
  const u=user(id);
  if(u.base!=='Inactive'&&curSR(id)){toast('Cannot deactivate',u.name+' is on an active service request.','err');return}
  u.base=u.base==='Inactive'?'Available':'Inactive';save();render();
  toast(u.base==='Inactive'?'User deactivated':'User activated',u.name+' is now '+u.base+'.','warn');
}
function viewUser(id){
  const u=user(id),st=uStatus(id),c=curSR(id),h=historyOf(id);
  const hrs=h.filter(r=>r.hours).reduce((a,r)=>a+r.hours,0);
  modal({title:u.name,eyebrow:u.role+' · '+u.empId,
    body:`<div style="display:flex;gap:14px;align-items:center;margin-bottom:18px">${av(u.name,52)}
      <div><div style="display:flex;gap:7px;align-items:center">${bdg(st)}${u.vehId?`<span class="b b-idle b-sq mono"><i></i>${esc(veh(u.vehId).reg)}</span>`:''}</div>
      <div style="color:var(--txt-2);font-size:12.5px;margin-top:5px">${esc(u.destination)}, ${esc(u.emirates)} · joined ${fmtDate(u.joinDate)}</div></div></div>
      <dl class="kv" style="margin-bottom:16px">
        <dt>Mobile</dt><dd class="mono">${esc(u.mobile)}</dd>
        <dt>Email</dt><dd>${esc(u.email)}</dd>
        <dt>Address</dt><dd>${esc(u.address||'—')}</dd>
        <dt>Supervisor</dt><dd>${u.supId?esc(user(u.supId).name):'—'}</dd>
        <dt>Base status</dt><dd>${esc(u.base)}</dd>
      </dl>
      <div class="panel" style="margin-bottom:14px"><div class="panel-t">Current assignment</div>
        ${c?`<span class="sr-no">#${c.srNo}</span> <b>${esc(c.client)}</b> — ${esc(c.serviceType)}
             <div style="color:var(--txt-2);font-size:12.5px;margin-top:4px">${esc(c.area)}, ${esc(c.emirates)} · ${bdg(c.status)} ${c.timeIn?`· started ${fmtTime(c.timeIn)}`:''}</div>`
           :'<span style="color:var(--txt-3);font-size:13px">Not on a job right now.</span>'}</div>
      <div class="stat-grid" style="grid-template-columns:repeat(3,1fr)">
        ${statCard('Total requests',h.length,'Attended','c')}
        ${statCard('Completed',h.filter(r=>['Work Completed','Closed'].includes(r.status)).length,'Signed off','d')}
        ${statCard('Working hours',hrs.toFixed(1),'Logged on site','w')}
      </div>`,
    footer:`<button class="btn l" onclick="openHistory('${u.id}')">${icon('hist',14)} Work history</button>
            <button class="btn" onclick="closeModal()">Close</button>
            <button class="btn btn-cool" onclick="openUser('${u.id}')">Edit user</button>`});
}
function openHistory(id){
  const u=user(id),h=historyOf(id);
  const done=h.filter(r=>['Work Completed','Closed'].includes(r.status));
  const hrs=h.filter(r=>r.hours).reduce((a,r)=>a+r.hours,0);
  modal({title:'Work history — '+u.name,eyebrow:u.role+' · '+u.empId,wide:true,
    body:`<div class="stat-grid" style="grid-template-columns:repeat(6,1fr);margin-bottom:16px">
      ${statCard('Total requests',h.length,'','c')}
      ${statCard('Completed',done.length,'','d')}
      ${statCard('Active',h.filter(r=>r.status==='Work Started').length,'','w')}
      ${statCard('AMC jobs',h.filter(r=>r.amc==='AMC').length,'')}
      ${statCard('Non-AMC jobs',h.filter(r=>r.amc==='Non-AMC').length,'','v')}
      ${statCard('Working hours',hrs.toFixed(1),'','h')}
    </div>
    ${h.length?`<div class="tbl-wrap card" style="box-shadow:none"><table>
      <thead><tr><th>Date</th><th>SR No</th><th>Client</th><th>Location</th><th>Service</th><th>Contract</th><th>Team</th><th>Vehicle</th><th>Time in</th><th>Time out</th><th>Hours</th><th>Status</th><th>Remarks</th></tr></thead>
      <tbody>${h.map(r=>`<tr>
        <td class="mono" style="font-size:11.5px">${fmtDate(r.timeIn||r.reportedDate)}</td>
        <td><span class="sr-no">#${r.srNo}</span></td>
        <td>${esc(r.client)}</td>
        <td>${esc(r.area)}<div style="color:var(--txt-3);font-size:11.5px">${esc(r.emirates)}</div></td>
        <td>${esc(r.serviceType)}<div style="color:var(--txt-3);font-size:11.5px">${esc(r.equipment)}</div></td>
        <td>${bdg(r.amc,1)}</td>
        <td style="font-size:12px">${esc(teamNames(r).join(', '))}</td>
        <td class="mono">${r.vehId?esc(veh(r.vehId).reg):'—'}</td>
        <td class="mono">${fmtTime(r.timeIn)}</td>
        <td class="mono">${r.timeOut?fmtTime(r.timeOut):'—'}</td>
        <td class="mono">${r.hours!=null?r.hours:'<span class="live" data-tick="'+r.timeIn+'"></span>'}</td>
        <td>${bdg(r.status)}</td>
        <td style="max-width:230px;font-size:12px;color:var(--txt-2)">${esc(r.remarks||'—')}</td>
      </tr>`).join('')}</tbody></table></div>`
    :`<div class="t-empty"><b>No service history yet</b>${esc(u.name)} has not been assigned to a completed request.</div>`}`,
    footer:`<button class="btn" onclick="closeModal()">Close</button>`});
  startTickers();
}
