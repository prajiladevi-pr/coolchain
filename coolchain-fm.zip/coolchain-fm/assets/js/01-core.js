/* =====================================================================
   CoolChain FM — Core utilities
   assets/js/01-core.js

   Persistence wrapper, formatting helpers, the inline icon set, avatar and
   photo helpers, toast messages, reference lists and status badges.
   ===================================================================== */

/* ---------- persistence (degrades to memory if storage is blocked) ---------- */
const KEY='coolchain.v1';
let mem={};
const store={
  get(k){try{const v=localStorage.getItem(k);return v===null?(k in mem?mem[k]:null):v}catch(e){return k in mem?mem[k]:null}},
  set(k,v){mem[k]=v;try{localStorage.setItem(k,v)}catch(e){}},
  del(k){delete mem[k];try{localStorage.removeItem(k)}catch(e){}}
};

/* ---------- small helpers ---------- */
const $=s=>document.querySelector(s);
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const pad=n=>String(n).padStart(2,'0');
const uid=p=>p+'-'+Math.random().toString(36).slice(2,7);
const D=(y,m,d,h=9,mi=0)=>new Date(y,m-1,d,h,mi).getTime();
const now=()=>Date.now();
function fmtDate(ts){if(!ts)return '—';const d=new Date(ts);return `${pad(d.getDate())} ${['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'][d.getMonth()]} ${d.getFullYear()}`}
function fmtTime(ts){if(!ts)return '—';const d=new Date(ts);let h=d.getHours(),ap=h<12?'AM':'PM';h=h%12||12;return `${pad(h)}:${pad(d.getMinutes())} ${ap}`}
function fmtDT(ts){return ts?fmtDate(ts)+' · '+fmtTime(ts):'—'}
function dur(ms){const t=Math.max(0,Math.floor(ms/1000));return `${pad(Math.floor(t/3600))}:${pad(Math.floor(t%3600/60))}:${pad(t%60)}`}
function hoursOf(a,b){if(!a||!b)return null;return Math.round((b-a)/36e5*100)/100}
function isToday(ts){if(!ts)return false;const a=new Date(ts),b=new Date();return a.toDateString()===b.toDateString()}
function daysAgo(n){const d=new Date();d.setDate(d.getDate()-n);d.setHours(10,0,0,0);return d.getTime()}
function ago(ts){const s=Math.floor((now()-ts)/1000);if(s<60)return 'just now';if(s<3600)return Math.floor(s/60)+'m ago';if(s<86400)return Math.floor(s/3600)+'h ago';return Math.floor(s/86400)+'d ago'}
const AV=['#0E8FA8','#5B54B8','#D9822B','#1E8E5A','#C8453C','#2E6B9E','#8A4FA8','#0F7B6C'];
function avColor(s){let h=0;for(const c of String(s))h=(h*31+c.charCodeAt(0))>>>0;return AV[h%AV.length]}
function initials(n){return String(n).trim().split(/\s+/).slice(0,2).map(w=>w[0]).join('').toUpperCase()}
function av(name,size){const s=size||30;return `<div class="avatar" style="background:${avColor(name)};width:${s}px;height:${s}px;font-size:${Math.round(s*.36)}px">${esc(initials(name))}</div>`}
/* image assets in assets/img — see also .photo / .empty-art in the stylesheet */
const IMG='assets/img/';
function photoPreview(name,size){const s=size||52;
  return name&&name.trim()
    ? av(name,s)
    : `<img class="photo" src="${IMG}avatar-placeholder.svg" alt="No profile photo" width="${s}" height="${s}">`}
function emptyArt(alt){return `<img class="empty-art" src="${IMG}empty-jobs.svg" alt="${esc(alt||'')}">`}
function icon(n,sz){const s=sz||16;const P={
 dash:'<rect x="3" y="3" width="7" height="9" rx="1.5"/><rect x="14" y="3" width="7" height="5" rx="1.5"/><rect x="14" y="12" width="7" height="9" rx="1.5"/><rect x="3" y="16" width="7" height="5" rx="1.5"/>',
 clip:'<path d="M9 2h6v3H9zM7 5H5a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2h-2"/><path d="M8 12h8M8 16h5"/>',
 users:'<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13A4 4 0 0 1 19 7a4 4 0 0 1-3 3.87"/>',
 van:'<path d="M1 16V7a1 1 0 0 1 1-1h11v10M13 8h4l4 4v4h-2"/><circle cx="6" cy="17" r="2"/><circle cx="17.5" cy="17" r="2"/><path d="M8 17h7.5M1 16h2"/>',
 shield:'<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>',
 pulse:'<path d="M22 12h-4l-3 8-4-16-3 8H2"/>',
 chart:'<path d="M3 3v18h18"/><path d="M7 15l4-5 4 3 5-7"/>',
 bell:'<path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9M13.7 21a2 2 0 0 1-3.4 0"/>',
 eye:'<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>',
 pen:'<path d="M17 3a2.8 2.8 0 0 1 4 4L7.5 20.5 2 22l1.5-5.5z"/>',
 send:'<path d="M22 2 11 13M22 2l-7 20-4-9-9-4z"/>',
 hist:'<path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5M12 8v4l3 2"/>',
 pin:'<path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0z"/><circle cx="12" cy="10" r="3"/>',
 play:'<path d="M6 3l14 9-14 9z"/>',
 check:'<path d="M20 6 9 17l-5-5"/>',
 x:'<path d="M18 6 6 18M6 6l12 12"/>',
 search:'<circle cx="11" cy="11" r="7"/><path d="M20 20l-4.5-4.5"/>',
 clock:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
 plus:'<path d="M12 5v14M5 12h14"/>',
 trash:'<path d="M3 6h18M8 6V4h8v2M6 6l1 14h10l1-14"/>',
 dl:'<path d="M12 3v12M7 11l5 5 5-5M4 21h16"/>',
 home:'<path d="M3 10l9-7 9 7v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
 user:'<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
 flag:'<path d="M4 22V3h11l-1.5 4L15 11H4"/>',
 wrench:'<path d="M14.5 3a5.5 5.5 0 0 0-5 8.2L3 17.7V21h3.3l6.5-6.5A5.5 5.5 0 1 0 14.5 3z"/>'
 };
 return `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${P[n]||''}</svg>`}

function toast(title,msg,kind){
  const el=document.createElement('div');
  el.className='toast '+(kind||'');
  const ic=kind==='ok'?'check':kind==='err'?'x':kind==='warn'?'flag':'pulse';
  el.innerHTML=`<span class="ic">${icon(ic,13)}</span><div><b>${esc(title)}</b>${msg?`<small>${esc(msg)}</small>`:''}</div>`;
  $('#toasts').appendChild(el);
  setTimeout(()=>{el.style.transition='.3s';el.style.opacity=0;el.style.transform='translateX(24px)';setTimeout(()=>el.remove(),320)},4200);
}

/* ---------- reference lists ---------- */
const ROLES=['Administrator','Dashboard Access User','Supervisor','Technical Staff','Driver'];
const USTATUS=['Available','Working','Assigned','On Leave','Inactive'];
const VSTATUS=['Available','Assigned','In Service','Maintenance','Inactive'];
const SRSTATUS=['New','Allocated','Work Started','Work Completed','Closed','Cancelled'];
const PRIOS=['Low','Medium','High','Critical'];
const STYPES=['AC Checking','Preventive Maintenance','Corrective Maintenance','Repair','Replacement','Cleaning','Water Service','Gas Charging','Electrical Work','Cooling Issue','Leakage Issue'];
const EQUIP=['Ductable AC','Cassette AC','Split AC','FCU','AHU','Chiller','Cold Room','Freezer Unit'];
const EMIRATES=['Dubai','Sharjah','Ajman','Abu Dhabi','Ras Al Khaimah'];
const CLIENTS=['Nesto Hypermarket','Last Chance Wholesale Market LLC','Al Maya Supermarket','Gulf Cold Store LLC'];
const AREAS=['Nad Al Hamar','Jabel Ali','Al Nahda-2','King Faisal','Mia Mall','Maleha','Ajman Industrial 1','Al Quoz'];

const badgeFor=(s)=>({
 'Available':'b-cool','Working':'b-warm','Assigned':'b-violet','On Leave':'b-idle','Inactive':'b-idle',
 'In Service':'b-warm','Maintenance':'b-hot',
 'New':'b-idle','Allocated':'b-violet','Work Started':'b-warm','Work Completed':'b-done','Closed':'b-cool','Cancelled':'b-hot',
 'Low':'b-idle','Medium':'b-cool','High':'b-warm','Critical':'b-hot','AMC':'b-cool','Non-AMC':'b-violet'
}[s]||'b-idle');
const bdg=(s,sq)=>s?`<span class="b ${badgeFor(s)}${sq?' b-sq':''}"><i></i>${esc(s)}</span>`:'—';
