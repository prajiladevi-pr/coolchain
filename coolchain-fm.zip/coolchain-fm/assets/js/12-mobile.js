/* =====================================================================
   CoolChain FM — Mobile apps
   assets/js/12-mobile.js

   Supervisor field app and admin monitoring app, both in the phone frame.
   ===================================================================== */

let phMode='sup',phTab='home',phSupId='U2',phSheet=null;

/* the phone app is a live view of the same state: refresh it whenever it is open */
function phLive(){return $('#phoneVeil').classList.contains('on')}
function afterAction(){render();if(phLive())phRender()}

/* status-driven actions — available in the supervisor app and the admin app alike */
function phActions(r,compact){
  const f=phMode==='sup'?'sup':'admin',w=compact?' style="width:100%;justify-content:center;margin-top:7px"':'',a=[];
  if(r.status==='New'&&phMode==='admin')a.push(`<button class="btn btn-cool"${w} onclick="event.stopPropagation();openAllocate('${r.srNo}')">${icon('users',14)} Allocate team &amp; vehicle</button>`);
  if(r.status==='Allocated')a.push(`<button class="btn btn-warm"${w} onclick="event.stopPropagation();startWork('${r.srNo}','${f}')">${icon('play',14)} Start work</button>`);
  if(r.status==='Work Started')a.push(`<button class="btn btn-done"${w} onclick="event.stopPropagation();openComplete('${r.srNo}','${f}')">${icon('check',14)} Complete work &amp; add remarks</button>`);
  if(r.status==='Work Completed'&&phMode==='admin')a.push(`<button class="btn btn-p"${w} onclick="event.stopPropagation();closeSR('${r.srNo}')">${icon('check',14)} Review &amp; close</button>`);
  return a.join('');
}
function openPhone(mode){
  phMode=mode;phTab='home';phSheet=null;
  if(mode==='sup'){
    const latest=S.requests.filter(r=>r.status==='Allocated'&&r.supId)
      .sort((a,b)=>(b.timeline[b.timeline.length-1]||{}).t-(a.timeline[a.timeline.length-1]||{}).t)[0];
    const withJob=S.users.filter(u=>u.role==='Supervisor'&&S.requests.some(r=>ACTIVE.includes(r.status)&&r.supId===u.id));
    phSupId=latest?latest.supId:(withJob[0]||S.users.find(u=>u.role==='Supervisor')).id;
  }
  $('#phoneVeil').classList.add('on');
  phRender();
}
function closePhone(){$('#phoneVeil').classList.remove('on');phSheet=null;render()}
function phGo(t){phTab=t;phSheet=null;phRender()}
const supUnread=()=>S.notifications.filter(n=>n.audience==='supervisor'&&n.userId===phSupId&&!n.read).length;

function phRender(){
  const tipEl=$('#phoneTip');
  if(phMode==='sup'){
    const u=user(phSupId);
    tipEl.innerHTML=`<h4>Supervisor app</h4><p style="margin:0 0 12px">Signed in as ${esc(u.name)}. Allocated jobs arrive as notifications; start and complete them from here and the admin dashboard follows instantly.</p>
      <ul><li>Open <b>Allocated</b> to see assigned work</li><li>Tap a job → <b>Start work</b> records time in</li><li><b>Complete work</b> captures remarks and hours</li></ul>
      <div class="field"><label style="color:rgba(255,255,255,.5)">Switch supervisor</label>
      <select class="inp" onchange="phSupId=this.value;phTab='home';phRender()">${opts(S.users.filter(x=>x.role==='Supervisor').map(x=>({v:x.id,l:x.name})),phSupId,'Select')}</select></div>`;
  }else{
    tipEl.innerHTML=`<h4>Admin app</h4><p style="margin:0 0 12px">The same operation, sized for a phone. Live counters, request queues by status, crew availability and fleet deployment.</p>
      <ul><li><b>Home</b> — today at a glance</li><li><b>Jobs</b> — queues by status</li><li><b>Team</b> and <b>Fleet</b> — who and what is free</li></ul>`;
  }
  const d=new Date();$('#phClock').textContent=`${pad(d.getHours()%12||12)}:${pad(d.getMinutes())}`;
  $('#phTop').innerHTML=phTop();
  $('#phBody').innerHTML=phMode==='sup'?phSup():phAdmin();
  $('#phNav').innerHTML=phNav();
  $('#phOverlay').innerHTML=phSheet?phSheetHTML():'';
  startTickers();
}
function phTop(){
  if(phMode==='sup'){
    const u=user(phSupId);
    return `${av(u.name,36)}<div><small>Supervisor</small><h3>${esc(u.name.split(' ')[0])}</h3></div>
      <div class="r">${bdg(uStatus(phSupId))}</div>`;
  }
  return `<img class="ph-logo" src="${IMG}logo-mark.svg" alt="CoolChain FM">
    <div><small>CoolChain FM</small><h3>Operations</h3></div>
    <div class="r"><span class="b b-cool"><i></i>Live</span></div>`;
}
function phNav(){
  const items=phMode==='sup'
    ?[['home','Home','home'],['allocated','Allocated','clip'],['completed','Completed','check'],['notif','Alerts','bell'],['profile','Profile','user']]
    :[['home','Home','home'],['requests','Jobs','clip'],['users','Team','users'],['vehicles','Fleet','van'],['notif','Alerts','bell'],['profile','Profile','user']];
  const n=phMode==='sup'?supUnread():unread('admin');
  return items.map(i=>`<button class="${phTab===i[0]?'on':''}" onclick="phGo('${i[0]}')">${icon(i[2],19)}<span>${i[1]}</span>${i[0]==='notif'&&n?`<span class="n">${n}</span>`:''}</button>`).join('');
}

/* ---------- supervisor screens ---------- */
function supJobs(status){return S.requests.filter(r=>r.supId===phSupId&&(status?(Array.isArray(status)?status.includes(r.status):r.status===status):true))}
function phSup(){
  const alloc=supJobs('Allocated'),run=supJobs('Work Started'),
        done=supJobs(['Work Completed','Closed']).sort((a,b)=>(b.timeOut||0)-(a.timeOut||0));
  if(phTab==='home'){
    const cur=run[0];
    return `<div class="ph-stat">
        <div><b>${alloc.length}</b><small>Allocated</small></div>
        <div><b style="color:var(--warm)">${run.length}</b><small>Started</small></div>
        <div><b style="color:var(--done)">${done.filter(r=>isToday(r.timeOut)).length}</b><small>Completed</small></div>
      </div>
      ${cur?`<div class="hero-job">
        <div class="eyebrow" style="color:rgba(255,255,255,.5)">Work in progress · #${cur.srNo}</div>
        <h4>${esc(cur.client)}</h4>
        <div style="font-size:12.5px;color:rgba(255,255,255,.7)">${esc(cur.area)}, ${esc(cur.emirates)} — ${esc(cur.equipment)} · ${esc(cur.serviceType)}</div>
        <div class="timer live" data-tick="${cur.timeIn}" style="color:#F0B45F">${dur(now()-cur.timeIn)}</div>
        <div style="font-size:11px;color:rgba(255,255,255,.5);font-family:'IBM Plex Mono'">Started ${fmtTime(cur.timeIn)}</div>
        <div class="team">
          <div><span>Supervisor</span>${esc(user(cur.supId).name)}</div>
          <div><span>Vehicle</span><span class="mono">${cur.vehId?esc(veh(cur.vehId).reg):'—'}</span></div>
          <div><span>Technicians</span>${(cur.techIds||[]).map(i=>esc(user(i).name)).join(', ')||'—'}</div>
          <div><span>Driver</span>${cur.driverId?esc(user(cur.driverId).name):'—'}</div>
        </div>
        <button class="btn btn-w btn-done" style="margin-top:13px" onclick="openComplete('${cur.srNo}','sup')">${icon('check',14)} Complete work &amp; add remarks</button>
        <button class="btn btn-w" style="margin-top:7px;background:#fff;border-color:#fff;color:var(--ink)" onclick="phOpen('${cur.srNo}')">View details</button>
      </div>`:`<div class="job" style="text-align:center;padding:22px 14px">
        ${emptyArt('No job running')}
        <b style="font-family:Archivo;font-size:15px">No job running</b>
        <p style="color:var(--txt-2);font-size:12.5px;margin:5px 0 0">Open an allocated request and start work to log time in.</p></div>`}
      <div class="ph-sec">Allocated to you (${alloc.length})</div>
      ${alloc.length?alloc.map(jobCard).join(''):`<div class="job" style="color:var(--txt-3);font-size:12.5px">Nothing waiting. New assignments arrive as notifications.</div>`}`;
  }
  if(phTab==='allocated'){
    return `<div class="ph-sec">Allocated jobs (${alloc.length})</div>
      ${alloc.length?alloc.map(jobCard).join(''):`<div class="job" style="color:var(--txt-3);font-size:12.5px">No allocated jobs right now.</div>`}
      ${run.length?`<div class="ph-sec">In progress (${run.length})</div>${run.map(jobCard).join('')}`:''}`;
  }
  if(phTab==='completed'){
    const hrs=done.filter(r=>r.hours).reduce((a,r)=>a+r.hours,0);
    return `<div class="ph-stat"><div><b>${done.length}</b><small>Jobs</small></div>
        <div><b>${hrs.toFixed(1)}</b><small>Hours</small></div>
        <div><b>${done.filter(r=>r.amc==='AMC').length}</b><small>AMC</small></div></div>
      <div class="ph-sec">Work history</div>
      ${done.length?done.map(r=>`<div class="job" onclick="phOpen('${r.srNo}')">
        <div class="job-h"><span class="sr-no">#${r.srNo}</span>${bdg(r.status)}${bdg(r.amc,1)}</div>
        <h4>${esc(r.client)}</h4>
        <p class="loc">${icon('pin',13)} ${esc(r.area)}, ${esc(r.emirates)}</p>
        <div class="meta">
          <div><span>Date</span>${fmtDate(r.timeIn||r.reportedDate)}</div>
          <div><span>Hours</span><span class="mono">${r.hours!=null?r.hours+' h':'—'}</span></div>
          <div><span>Time in</span><span class="mono">${fmtTime(r.timeIn)}</span></div>
          <div><span>Time out</span><span class="mono">${r.timeOut?fmtTime(r.timeOut):'—'}</span></div>
        </div>
        ${r.remarks?`<div class="desc">${esc(r.remarks)}</div>`:''}</div>`).join('')
      :`<div class="job" style="color:var(--txt-3);font-size:12.5px">No completed jobs yet.</div>`}`;
  }
  if(phTab==='notif'){
    const list=S.notifications.filter(n=>n.audience==='supervisor'&&n.userId===phSupId);
    return `<div style="display:flex;align-items:center;margin-bottom:8px"><div class="ph-sec" style="margin:0">Notifications</div>
      ${list.length?`<button class="btn btn-sm" style="margin-left:auto" onclick="markAllRead('supervisor')">Mark read</button>`:''}</div>
      <div class="card" style="overflow:hidden">${list.length?list.map(n=>`<div class="notif ${n.read?'':'un'}" ${n.srNo?`onclick="readNotifSup('${n.id}');phOpen('${n.srNo}')"`:`onclick="readNotifSup('${n.id}')"`}>
        ${notifIcon(n.title)}<div style="flex:1;min-width:0"><b>${esc(n.title)}</b><p>${esc(n.body)}</p></div><time>${ago(n.t)}</time></div>`).join('')
      :`<div class="t-empty" style="padding:30px 16px"><b>All clear</b>Assignment alerts land here.</div>`}</div>`;
  }
  const u=user(phSupId),all=supJobs(),hrs=all.filter(r=>r.hours).reduce((a,r)=>a+r.hours,0);
  return `<div class="job" style="text-align:center;padding:20px">
      ${av(u.name,64)}
      <h4 style="margin:12px 0 2px;font-size:18px">${esc(u.name)}</h4>
      <div class="eyebrow">${esc(u.role)} · ${esc(u.empId)}</div>
      <div style="margin-top:10px">${bdg(uStatus(u.id))}</div></div>
    <div class="ph-stat"><div><b>${all.length}</b><small>Total SR</small></div>
      <div><b>${all.filter(r=>['Work Completed','Closed'].includes(r.status)).length}</b><small>Done</small></div>
      <div><b>${hrs.toFixed(0)}</b><small>Hours</small></div></div>
    <div class="job"><div class="ph-sec" style="margin:0 0 9px">Details</div>
      <dl class="kv" style="grid-template-columns:96px 1fr">
        <dt>Mobile</dt><dd class="mono">${esc(u.mobile)}</dd>
        <dt>Email</dt><dd style="font-size:12px">${esc(u.email)}</dd>
        <dt>Destination</dt><dd>${esc(u.destination)}</dd>
        <dt>Emirates</dt><dd>${esc(u.emirates)}</dd>
        <dt>Vehicle</dt><dd class="mono">${u.vehId?esc(veh(u.vehId).reg):'—'}</dd>
        <dt>Joined</dt><dd>${fmtDate(u.joinDate)}</dd></dl></div>
    <div class="job"><div class="ph-sec" style="margin:0 0 9px">My team</div>
      ${S.users.filter(x=>x.supId===u.id).map(x=>`<div class="res">${av(x.name,24)}<div><b>${esc(x.name)}</b><div class="eyebrow">${esc(x.role)}</div></div><span class="st">${bdg(uStatus(x.id))}</span></div>`).join('')||'<span style="color:var(--txt-3);font-size:12.5px">No crew assigned.</span>'}</div>
    <button class="btn btn-w btn-cool" style="margin-bottom:8px" onclick="openPhone('admin')">${icon('dash',14)} Switch to admin app</button>
    <button class="btn btn-w" onclick="closePhone()">Sign out of app</button>`;
}
function readNotifSup(id){const n=S.notifications.find(x=>x.id===id);if(n)n.read=true;save()}
function jobCard(r){
  return `<div class="job">
    <div class="job-h"><span class="sr-no">#${r.srNo}</span>${bdg(r.status)}${bdg(r.priority,1)}${bdg(r.amc,1)}</div>
    <h4>${esc(r.client)}</h4>
    <p class="loc">${icon('pin',13)} ${esc(r.area)}, ${esc(r.emirates)} · ${esc(r.location||'')}</p>
    <div class="desc">${esc(r.description||r.items.map(i=>i.work).join('; '))}</div>
    <div class="meta">
      <div><span>Equipment</span>${esc(r.equipment)}</div>
      <div><span>Service</span>${esc(r.serviceType)}</div>
      <div><span>Fix by</span>${fmtDate(r.expectedFix)}</div>
      <div><span>Vehicle</span><span class="mono">${r.vehId?esc(veh(r.vehId).reg):'—'}</span></div>
      <div style="grid-column:span 2"><span>Team</span>${esc(teamNames(r).join(' · '))}</div>
    </div>
    ${phActions(r,true)}
    <button class="btn btn-sm" style="width:100%;justify-content:center;margin-top:7px" onclick="phOpen('${r.srNo}')">View details</button>
  </div>`;
}
function phOpen(srNo){phSheet=srNo;phRender()}
function phCloseSheet(){phSheet=null;phRender()}
function phSheetHTML(){
  const r=sr(phSheet);if(!r)return '';
  return `<div class="ph-mask" onclick="phCloseSheet()"></div>
  <div class="sheet"><div class="grab"></div>
    <div class="sheet-h"><div><div class="eyebrow">SR #${r.srNo}${r.projectNo?' · '+esc(r.projectNo):''}</div><h4>${esc(r.client)}</h4></div>
      <button class="btn btn-icon" style="margin-left:auto" onclick="phCloseSheet()">${icon('x',14)}</button></div>
    <div class="sheet-b">
      <div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:13px">${bdg(r.status)}${bdg(r.priority,1)}${bdg(r.amc,1)}</div>
      <p class="loc" style="margin-bottom:12px">${icon('pin',13)} ${esc(r.area)}, ${esc(r.emirates)} · ${esc(r.location||'')}</p>
      <div class="ph-sec">Work required</div>
      <div class="desc" style="margin-bottom:14px">${esc(r.description||'—')}</div>
      <div class="ph-sec">Service items (${r.items.length})</div>
      ${r.items.map((i,n)=>`<div class="res" style="align-items:flex-start"><span class="mono" style="color:var(--txt-3)">${n+1}</span>
        <div><b>${esc(i.work)}</b><div style="color:var(--txt-3);font-size:11.5px">${esc(i.floor||'—')} · ${esc(i.equipment)} · qty ${i.qty}</div></div></div>`).join('')}
      <div class="ph-sec">Team &amp; vehicle</div>
      ${teamIds(r).map(i=>`<div class="res">${av(user(i).name,22)}<div><b>${esc(user(i).name)}</b><div class="eyebrow">${esc(user(i).role)}</div></div><span class="st">${bdg(uStatus(i))}</span></div>`).join('')}
      ${r.vehId?`<div class="res"><span class="mono" style="font-weight:600">${esc(veh(r.vehId).reg)}</span><span style="font-size:11.5px;color:var(--txt-3)">${esc(veh(r.vehId).type)}</span><span class="st">${bdg(vStatus(r.vehId))}</span></div>`:''}
      <div class="ph-sec">Time</div>
      <dl class="kv" style="grid-template-columns:96px 1fr">
        <dt>Scheduled</dt><dd>${fmtDate(r.scheduledDate)}</dd>
        <dt>Fix by</dt><dd>${fmtDate(r.expectedFix)}</dd>
        <dt>Time in</dt><dd class="mono">${r.timeIn?fmtTime(r.timeIn):'—'}</dd>
        <dt>Time out</dt><dd class="mono">${r.timeOut?fmtTime(r.timeOut):'—'}</dd>
        <dt>Hours</dt><dd class="mono">${r.hours!=null?r.hours+' h':(r.timeIn?`<span class="live" data-tick="${r.timeIn}"></span>`:'—')}</dd></dl>
      ${r.workPerformed?`<div class="ph-sec">Completion</div><div class="desc">${esc(r.workPerformed)}${r.remarks?'\n\n'+esc(r.remarks):''}</div>`:''}
      <div class="ph-sec">Timeline</div>
      <ul class="tl">${r.timeline.slice().sort((a,b)=>a.t-b.t).map((t,i,a)=>`<li class="${i===a.length-1?'acc':''}"><time>${fmtTime(t.t)}</time><b>${esc(t.e)}</b><p>${esc(t.by||'')}</p></li>`).join('')}</ul>
    </div>
    <div class="sheet-f">
      ${phActions(r)}
      <button class="btn" onclick="phCloseSheet()">Close</button>
    </div></div>`;
}

/* ---------- admin mobile screens ---------- */
function phAdmin(){
  const c=counts(),fu=fieldUsers();
  if(phTab==='home'){
    const live=S.requests.filter(r=>r.status==='Work Started');
    return `<div class="ph-stat">
        <div><b>${c.today}</b><small>Today</small></div>
        <div><b style="color:var(--warm)">${c.tStart+c.tAlloc}</b><small>Active</small></div>
        <div><b style="color:var(--done)">${c.tDone}</b><small>Completed</small></div>
      </div>
      <div class="ph-stat">
        <div><b style="color:var(--cool)">${c.uFree}</b><small>Free crew</small></div>
        <div><b style="color:var(--warm)">${c.uWork}</b><small>Working</small></div>
        <div><b>${c.vFree}</b><small>Free vans</small></div>
      </div>
      <div class="ph-sec">Running now (${live.length})</div>
      ${live.length?live.map(r=>`<div class="job" onclick="phOpen('${r.srNo}')">
        <div class="job-h"><span class="sr-no">#${r.srNo}</span>${bdg(r.status)}<span class="live mono" style="margin-left:auto" data-tick="${r.timeIn}"></span></div>
        <h4>${esc(r.client)}</h4><p class="loc">${icon('pin',13)} ${esc(r.area)} · ${esc(r.serviceType)}</p>
        <div class="meta"><div><span>Supervisor</span>${esc(sup(r)?sup(r).name:'—')}</div>
          <div><span>Vehicle</span><span class="mono">${r.vehId?esc(veh(r.vehId).reg):'—'}</span></div></div>
        ${phActions(r,true)}</div>`).join('')
      :`<div class="job" style="color:var(--txt-3);font-size:12.5px">No job in progress.</div>`}
      <div class="ph-sec">Awaiting allocation (${c.tPend})</div>
      ${S.requests.filter(r=>r.status==='New').map(r=>`<div class="job" onclick="phOpen('${r.srNo}')">
        <div class="job-h"><span class="sr-no">#${r.srNo}</span>${bdg(r.priority,1)}</div>
        <h4>${esc(r.client)}</h4><p class="loc" style="margin:0 0 7px">${icon('pin',13)} ${esc(r.area)} · ${esc(r.serviceType)}</p>
        ${phActions(r,true)}</div>`).join('')
      ||`<div class="job" style="color:var(--txt-3);font-size:12.5px">Queue is clear.</div>`}`;
  }
  if(phTab==='requests'){
    const g=s=>S.requests.filter(r=>r.status===s);
    return ['New','Allocated','Work Started','Work Completed'].map(s=>`
      <div class="ph-sec">${s} (${g(s).length})</div>
      ${g(s).length?g(s).slice(0,6).map(r=>`<div class="job" onclick="phOpen('${r.srNo}')">
        <div class="job-h"><span class="sr-no">#${r.srNo}</span>${bdg(r.priority,1)}${bdg(r.amc,1)}</div>
        <h4>${esc(r.client)}</h4><p class="loc" style="margin:0 0 7px">${icon('pin',13)} ${esc(r.area)}, ${esc(r.emirates)}</p>
        <div class="meta" style="margin:0"><div><span>Service</span>${esc(r.serviceType)}</div>
          <div><span>Supervisor</span>${esc(sup(r)?sup(r).name:'—')}</div></div>
        ${r.timeIn?`<div class="meta" style="margin:7px 0 0"><div><span>Time in</span><span class="mono">${fmtTime(r.timeIn)}</span></div>
          <div><span>${r.hours!=null?'Hours':'Running'}</span><span class="mono">${r.hours!=null?r.hours+' h':`<span class="live" data-tick="${r.timeIn}"></span>`}</span></div></div>`:''}
        ${r.remarks?`<div class="desc" style="margin-top:8px">${esc(r.remarks)}</div>`:''}
        ${phActions(r,true)}</div>`).join('')
      :`<div class="job" style="color:var(--txt-3);font-size:12.5px">None.</div>`}`).join('');
  }
  if(phTab==='users'){
    const free=fu.filter(u=>uStatus(u.id)==='Available'),busy=fu.filter(u=>['Working','Assigned'].includes(uStatus(u.id)));
    const row=u=>{const c=curSR(u.id);return `<div class="job" style="padding:11px">
      <div class="mini-h" style="margin:0">${av(u.name,32)}<div><b style="font-family:Archivo">${esc(u.name)}</b><div class="eyebrow">${esc(u.role)}</div></div>
        <span style="margin-left:auto">${bdg(uStatus(u.id))}</span></div>
      ${c?`<div class="meta" style="margin:9px 0 0"><div><span>Current SR</span>#${c.srNo} ${esc(c.client)}</div>
        <div><span>Since</span><span class="mono">${c.timeIn?fmtTime(c.timeIn):'—'}</span></div></div>`:''}</div>`};
    return `<div class="ph-sec">Working (${busy.length})</div>${busy.map(row).join('')||`<div class="job" style="color:var(--txt-3);font-size:12.5px">Nobody engaged.</div>`}
      <div class="ph-sec">Available (${free.length})</div>${free.map(row).join('')||`<div class="job" style="color:var(--txt-3);font-size:12.5px">Nobody free.</div>`}`;
  }
  if(phTab==='vehicles'){
    const row=v=>{const c=curSRVeh(v.id);return `<div class="job" style="padding:11px">
      <div class="job-h" style="margin:0"><b class="mono" style="font-size:14px">${esc(v.reg)}</b>${bdg(vStatus(v.id))}</div>
      <div class="meta" style="margin:9px 0 0">
        <div><span>Type</span>${esc(v.type)}</div><div><span>Driver</span>${v.driverId?esc(user(v.driverId).name):'—'}</div>
        ${c?`<div><span>Current SR</span>#${c.srNo}</div><div><span>Client</span>${esc(c.client)}</div>`:`<div><span>Location</span>${esc(v.location)}</div>`}
      </div></div>`};
    const g=s=>S.vehicles.filter(v=>vStatus(v.id)===s);
    return `<div class="ph-sec">In service (${g('In Service').length})</div>${g('In Service').map(row).join('')||`<div class="job" style="color:var(--txt-3);font-size:12.5px">None out.</div>`}
      <div class="ph-sec">Assigned (${g('Assigned').length})</div>${g('Assigned').map(row).join('')||`<div class="job" style="color:var(--txt-3);font-size:12.5px">None.</div>`}
      <div class="ph-sec">Available (${g('Available').length})</div>${g('Available').map(row).join('')||`<div class="job" style="color:var(--txt-3);font-size:12.5px">None free.</div>`}
      <div class="ph-sec">Maintenance (${g('Maintenance').length})</div>${g('Maintenance').map(row).join('')||`<div class="job" style="color:var(--txt-3);font-size:12.5px">None.</div>`}`;
  }
  if(phTab==='notif'){
    const list=S.notifications.filter(n=>n.audience==='admin');
    return `<div style="display:flex;align-items:center;margin-bottom:8px"><div class="ph-sec" style="margin:0">Alerts</div>
      <button class="btn btn-sm" style="margin-left:auto" onclick="markAllRead('admin');phRender()">Mark read</button></div>
      <div class="card" style="overflow:hidden">${list.map(n=>`<div class="notif ${n.read?'':'un'}" ${n.srNo?`onclick="readNotif('${n.id}');phOpen('${n.srNo}')"`:''}>
        ${notifIcon(n.title)}<div style="flex:1;min-width:0"><b>${esc(n.title)}</b><p>${esc(n.body)}</p></div><time>${ago(n.t)}</time></div>`).join('')||`<div class="t-empty" style="padding:30px"><b>All clear</b>No alerts.</div>`}</div>`;
  }
  return `<div class="job" style="text-align:center;padding:20px">${av('System Administrator',64)}
      <h4 style="margin:12px 0 2px;font-size:18px">System Administrator</h4><div class="eyebrow">Administrator · EMP-001</div></div>
    <div class="ph-stat"><div><b>${S.requests.length}</b><small>Requests</small></div><div><b>${S.users.length}</b><small>Users</small></div><div><b>${S.vehicles.length}</b><small>Vehicles</small></div></div>
    <div class="job"><div class="ph-sec" style="margin:0 0 9px">Operation</div>
      <dl class="kv" style="grid-template-columns:110px 1fr">
        <dt>Company</dt><dd>CoolChain FM</dd><dt>Coverage</dt><dd>Dubai, Sharjah, Ajman</dd>
        <dt>Contracts</dt><dd>${counts().amc} AMC · ${counts().nonamc} Non-AMC</dd>
        <dt>Open jobs</dt><dd>${counts().open}</dd></dl></div>
    <button class="btn btn-w btn-cool" style="margin-bottom:8px" onclick="openPhone('sup')">${icon('user',14)} Switch to supervisor field app</button>
    <button class="btn btn-w" onclick="closePhone()">Back to web portal</button>`;
}
