/* =====================================================================
   CoolChain FM — Modals & service request detail
   assets/js/06-modals.js

   Generic dialog host, confirmation prompt and the full SR detail view.
   ===================================================================== */

function modal({title,eyebrow,body,footer,wide,slim}){
  $('#modalHost').innerHTML=`<div class="veil" onclick="if(event.target===this)closeModal()">
    <div class="modal ${wide?'wide':''}${slim?' slim':''}" role="dialog" aria-modal="true">
      <div class="modal-h"><div>${eyebrow?`<div class="eyebrow">${esc(eyebrow)}</div>`:''}<h3>${esc(title)}</h3></div>
        <button class="x" onclick="closeModal()" aria-label="Close">${icon('x',15)}</button></div>
      <div class="modal-b">${body}</div>
      ${footer?`<div class="modal-f">${footer}</div>`:''}
    </div></div>`;
  document.addEventListener('keydown',escClose);
}
function escClose(e){if(e.key==='Escape')closeModal()}
function closeModal(){$('#modalHost').innerHTML='';document.removeEventListener('keydown',escClose)}
let confirmFn=null;
function confirmBox(title,msg,label,cls,fn){
  confirmFn=fn;
  modal({title,slim:true,body:`<p style="margin:0;color:var(--txt-2)">${esc(msg)}</p>`,
    footer:`<button class="btn l" onclick="closeModal()">Not now</button><button class="btn ${cls}" onclick="confirmFn&&confirmFn()">${esc(label)}</button>`});
}

/* ---------- SR detail ---------- */
function viewSR(srNo){
  const r=sr(srNo);if(!r)return;
  const acts=[];
  if(r.status==='New')acts.push(`<button class="btn btn-cool" onclick="openAllocate('${r.srNo}')">Allocate</button>`);
  if(r.status==='Allocated')acts.push(`<button class="btn btn-warm" onclick="startWork('${r.srNo}','admin')">Start work</button>`);
  if(r.status==='Work Started')acts.push(`<button class="btn btn-done" onclick="openComplete('${r.srNo}','admin')">Complete work</button>`);
  if(r.status==='Work Completed')acts.push(`<button class="btn btn-p" onclick="closeSR('${r.srNo}')">Close request</button>`);
  if(['New','Allocated'].includes(r.status))acts.push(`<button class="btn btn-danger" onclick="cancelSR('${r.srNo}')">Cancel</button>`);
  modal({title:'Service request #'+r.srNo,eyebrow:`${r.client} · ${r.area}, ${r.emirates}`,wide:true,
    body:`
    <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:16px">${bdg(r.status)} ${bdg(r.priority,1)} ${bdg(r.amc,1)}
      <span class="b b-idle b-sq"><i></i>${esc(r.serviceType)}</span><span class="b b-idle b-sq"><i></i>${esc(r.equipment)}</span>
      ${r.projectNo?`<span class="b b-idle b-sq mono"><i></i>${esc(r.projectNo)}</span>`:''}</div>
    <div class="grid2" style="gap:16px">
      <div>
        <div class="panel" style="margin-bottom:14px"><div class="panel-t">Service description</div>
          <div style="font-size:13.5px">${esc(r.description||'—')}</div></div>
        <div class="panel" style="margin-bottom:14px"><div class="panel-t">Service items (${r.items.length})</div>
          <div class="tbl-wrap"><table><thead><tr><th>#</th><th>Floor / area</th><th>Equipment</th><th>Work required</th><th>Qty</th></tr></thead>
          <tbody>${r.items.map((i,n)=>`<tr><td class="mono">${n+1}</td><td>${esc(i.floor||'—')}</td><td>${esc(i.equipment)}</td><td>${esc(i.work)}</td><td class="mono">${i.qty}</td></tr>`).join('')}</tbody></table></div></div>
        <div class="panel"><div class="panel-t">Dates &amp; time</div>
          <dl class="kv">
            <dt>Reported</dt><dd class="mono">${fmtDT(r.reportedDate)}</dd>
            <dt>Scheduled</dt><dd class="mono">${fmtDate(r.scheduledDate)}</dd>
            <dt>Expected fix</dt><dd class="mono">${fmtDate(r.expectedFix)}</dd>
            <dt>Time in</dt><dd class="mono">${r.timeIn?fmtDT(r.timeIn):'—'}</dd>
            <dt>Time out</dt><dd class="mono">${r.timeOut?fmtDT(r.timeOut):'—'}</dd>
            <dt>Working hours</dt><dd class="mono">${r.hours!=null?r.hours+' h':(r.timeIn?`<span class="live" data-tick="${r.timeIn}">${dur(now()-r.timeIn)}</span> running`:'—')}</dd>
          </dl></div>
      </div>
      <div>
        <div class="panel" style="margin-bottom:14px"><div class="panel-t">Assigned team</div>
          ${r.supId?`<div class="res">${av(user(r.supId).name,24)}<div><b>${esc(user(r.supId).name)}</b><div class="eyebrow">Supervisor</div></div><span class="st">${bdg(uStatus(r.supId))}</span></div>`:'<div style="color:var(--txt-3);font-size:13px">No supervisor yet</div>'}
          ${(r.techIds||[]).map(i=>`<div class="res">${av(user(i).name,24)}<div><b>${esc(user(i).name)}</b><div class="eyebrow">Technical staff</div></div><span class="st">${bdg(uStatus(i))}</span></div>`).join('')}
          ${r.driverId?`<div class="res">${av(user(r.driverId).name,24)}<div><b>${esc(user(r.driverId).name)}</b><div class="eyebrow">Driver</div></div><span class="st">${bdg(uStatus(r.driverId))}</span></div>`:''}
          ${r.vehId?`<div class="res"><span class="mono" style="font-weight:600">${esc(veh(r.vehId).reg)}</span><span style="color:var(--txt-3);font-size:12px">${esc(veh(r.vehId).type)}</span><span class="st">${bdg(vStatus(r.vehId))}</span></div>`:''}
        </div>
        ${r.workPerformed||r.remarks?`<div class="panel" style="margin-bottom:14px"><div class="panel-t">Completion record</div>
          <dl class="kv">
            <dt>Work performed</dt><dd>${esc(r.workPerformed||'—')}</dd>
            <dt>Remarks</dt><dd>${esc(r.remarks||'—')}</dd>
            ${r.material?`<dt>Material used</dt><dd>${esc(r.material)}</dd>`:''}
            <dt>Replacement</dt><dd>${esc(r.replacement)}</dd>
            <dt>Follow-up</dt><dd>${esc(r.followUp)}</dd>
            ${r.notes?`<dt>Notes</dt><dd>${esc(r.notes)}</dd>`:''}
          </dl></div>`:''}
        <div class="panel"><div class="panel-t">Timeline</div>
          <ul class="tl">${r.timeline.slice().sort((a,b)=>a.t-b.t).map((t,i,arr)=>`<li class="${i===arr.length-1?'acc':''}"><time>${fmtTime(t.t)}</time><b>${esc(t.e)}</b><p>${esc(t.by||'')}</p></li>`).join('')}</ul></div>
      </div>
    </div>`,
    footer:`<button class="btn l" onclick="openSR('${r.srNo}')">${icon('pen',14)} Edit</button>
            <button class="btn" onclick="closeModal()">Close</button>${acts.join('')}`});
  startTickers();
}
