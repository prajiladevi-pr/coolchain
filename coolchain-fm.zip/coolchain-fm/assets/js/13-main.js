/* =====================================================================
   CoolChain FM — Login & boot
   assets/js/13-main.js

   Demo authentication (admin / admin), clock and start-up.
   ===================================================================== */

function doLogin(){
  const u=$('#u').value.trim().toLowerCase(),p=$('#p').value;
  const e=$('#lgErr');
  if(!u||!p){e.textContent='Enter both a username and password.';e.style.display='block';return}
  if(u!=='admin'||p!=='admin'){
    e.textContent='Those credentials are not recognised. Use admin / admin for this demo.';e.style.display='block';
    $('#p').value='';$('#p').focus();return
  }
  e.style.display='none';
  if($('#rem').checked)store.set(KEY+'.session','1');
  enterApp();
  toast('Signed in','Welcome back — '+counts().open+' open service requests today.','ok');
}
function enterApp(){
  $('#login').style.display='none';
  $('#app').classList.add('on');
  page='dashboard';render();
}
function logout(){
  store.del(KEY+'.session');
  $('#app').classList.remove('on');$('#login').style.display='grid';
  $('#u').value='';$('#p').value='';
  toast('Signed out','Demo data is kept so you can pick up where you left off.');
}
function tickClock(){
  const d=new Date();
  const el=$('#clock');
  if(el)el.textContent=`${['Sun','Mon','Tue','Wed','Thu','Fri','Sat'][d.getDay()]} ${pad(d.getDate())} ${['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'][d.getMonth()]} · ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
}

/* ---------- boot ---------- */
load();
$('#lgSR').textContent=counts().open;
$('#lgCrew').textContent=fieldUsers().length;
$('#lgVeh').textContent=S.vehicles.length;
$('#u').addEventListener('keydown',e=>{if(e.key==='Enter')$('#p').focus()});
$('#p').addEventListener('keydown',e=>{if(e.key==='Enter')doLogin()});
tickClock();setInterval(tickClock,1000);
setInterval(()=>{if($('#phoneVeil').classList.contains('on')){const d=new Date();$('#phClock').textContent=`${pad(d.getHours()%12||12)}:${pad(d.getMinutes())}`}},20000);
if(store.get(KEY+'.session')==='1'){$('#rem').checked=true;$('#u').value='admin';enterApp()}

/* reset hook for the demo */
window.addEventListener('keydown',e=>{if(e.altKey&&e.key.toLowerCase()==='r'){resetAll()}});
