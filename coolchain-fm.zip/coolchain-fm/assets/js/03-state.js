/* =====================================================================
   CoolChain FM — Derived state & navigation
   assets/js/03-state.js

   Employee and vehicle availability is calculated from live service requests,
   never stored, so counters can never drift out of step with the work.
   ===================================================================== */

const user=id=>S.users.find(u=>u.id===id);
const veh=id=>S.vehicles.find(v=>v.id===id);
const sr=no=>S.requests.find(r=>r.srNo===no);
const sup=r=>r&&r.supId?user(r.supId):null;
const teamIds=r=>[r.supId,...(r.techIds||[]),r.driverId].filter(Boolean);
const teamNames=r=>teamIds(r).map(i=>(user(i)||{}).name).filter(Boolean);
const ACTIVE=['Allocated','Work Started'];

function uStatus(id){
  const u=user(id);if(!u)return '—';
  if(u.base==='Inactive'||u.base==='On Leave')return u.base;
  const mine=S.requests.filter(r=>ACTIVE.includes(r.status)&&teamIds(r).includes(id));
  if(mine.some(r=>r.status==='Work Started')) return id===mine.find(r=>r.status==='Work Started').driverId?'Assigned':'Working';
  if(mine.length) return 'Assigned';
  return 'Available';
}
function vStatus(id){
  const v=veh(id);if(!v)return '—';
  if(v.base==='Maintenance'||v.base==='Inactive')return v.base;
  const mine=S.requests.filter(r=>ACTIVE.includes(r.status)&&r.vehId===id);
  if(mine.some(r=>r.status==='Work Started'))return 'In Service';
  if(mine.length)return 'Assigned';
  return 'Available';
}
const curSR=id=>S.requests.find(r=>ACTIVE.includes(r.status)&&teamIds(r).includes(id));
const curSRVeh=id=>S.requests.find(r=>ACTIVE.includes(r.status)&&r.vehId===id);
const fieldUsers=()=>S.users.filter(u=>['Supervisor','Technical Staff','Driver'].includes(u.role));
function historyOf(id){
  return S.requests.filter(r=>teamIds(r).includes(id)&&['Work Completed','Closed','Work Started'].includes(r.status))
    .sort((a,b)=>(b.timeIn||0)-(a.timeIn||0));
}
function nextSR(){const n=S.srSeq++;save();return String(n)}

/* =====================================================================
   NAVIGATION
   ===================================================================== */
const PAGES=[
  {g:'Operations'},
  {k:'dashboard',t:'Dashboard',s:'Overview',i:'dash'},
  {k:'requests',t:'Service Requests',s:'Complaints & service work',i:'clip',count:()=>S.requests.filter(r=>['New','Allocated','Work Started'].includes(r.status)).length},
  {k:'monitoring',t:'Work Monitoring',s:'Who is free, who is on a job',i:'pulse'},
  {k:'vehmon',t:'Vehicle Monitoring',s:'Fleet deployment',i:'van'},
  {g:'Master data'},
  {k:'users',t:'User Management',s:'Employees, roles and teams',i:'users'},
  {k:'vehicles',t:'Vehicle Management',s:'Service fleet register',i:'van'},
  {k:'access',t:'Dashboard Access',s:'Who can see the dashboard',i:'shield'},
  {g:'Insight'},
  {k:'reports',t:'Reports',s:'Service, employee and fleet reporting',i:'chart'},
  {k:'notifications',t:'Notifications',s:'Operations alerts',i:'bell',count:()=>unread('admin'),hot:true}
];
let page='dashboard';
const unread=a=>S.notifications.filter(n=>n.audience===a&&!n.read).length;

function buildNav(){
  $('#nav').innerHTML=PAGES.map(p=>{
    if(p.g)return `<div class="nav-lbl">${p.g}</div>`;
    const c=p.count?p.count():0;
    return `<a href="#" onclick="go('${p.k}');return false" class="${page===p.k?'on':''}">${icon(p.i,16)}<span>${p.t}</span>${c?`<span class="pill${p.hot?' hot':''}">${c}</span>`:''}</a>`;
  }).join('');
  const u=unread('admin');
  $('#bellDot').style.display=u?'grid':'none';$('#bellDot').textContent=u;
}
function go(k){page=k;const m=$('#main');if(m&&m.scrollTo)m.scrollTo({top:0});render()}
function render(){
  const p=PAGES.find(x=>x.k===page)||PAGES[1];
  $('#pageTitle').textContent=p.t;$('#crumb').textContent=p.s;
  buildNav();
  const V={dashboard:vDash,requests:vRequests,monitoring:vMon,vehmon:vVehMon,users:vUsers,vehicles:vVehicles,access:vAccess,reports:vReports,notifications:vNotifs};
  $('#view').innerHTML=(V[page]||vDash)();
  if(afterRender.length){afterRender.forEach(f=>f());afterRender=[]}
  save();
}
let afterRender=[];
const later=f=>afterRender.push(f);
