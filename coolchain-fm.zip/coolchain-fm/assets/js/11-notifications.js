/* =====================================================================
   CoolChain FM — Notifications
   assets/js/11-notifications.js

   Admin alert feed and read-state handling.
   ===================================================================== */

function notifIcon(t){
  const m={'Work started':['warm','play'],'Work completed':['done','check'],'Service overdue':['hot','clock'],
    'Vehicle unavailable':['hot','van'],'User unavailable':['idle','user'],'Service request registered':['cool','clip'],
    'Follow-up flagged':['warm','flag'],'New service request assigned':['violet','send'],'Work reminder':['cool','clock']};
  const [c,i]=m[t]||['cool','bell'];
  const bg={cool:'var(--cool-soft)',warm:'var(--warm-soft)',hot:'var(--hot-soft)',done:'var(--done-soft)',idle:'var(--idle-soft)',violet:'var(--violet-soft)'}[c];
  const fg={cool:'#0A6E82',warm:'#96581A',hot:'#98322B',done:'#146342',idle:'#556579',violet:'#403A96'}[c];
  return `<span class="ic" style="background:${bg};color:${fg}">${icon(i,15)}</span>`;
}
function vNotifs(){
  const list=S.notifications.filter(n=>n.audience==='admin');
  return `<div class="card">
    <div class="card-h"><div><h3>Operations notifications</h3><div class="eyebrow" style="margin-top:2px">${unread('admin')} unread of ${list.length}</div></div>
      <button class="btn btn-sm" onclick="markAllRead('admin')">Mark all read</button></div>
    ${list.length?list.map(n=>`<div class="notif ${n.read?'':'un'}" ${n.srNo?`style="cursor:pointer" onclick="readNotif('${n.id}');viewSR('${n.srNo}')"`:`onclick="readNotif('${n.id}')"`}>
      ${notifIcon(n.title)}
      <div style="flex:1"><b>${esc(n.title)}</b><p>${esc(n.body)}</p></div>
      <time>${ago(n.t)}</time></div>`).join('')
    :`<div class="t-empty"><b>No notifications</b>Alerts appear here when work starts, completes or runs late.</div>`}
  </div>`;
}
function readNotif(id){const n=S.notifications.find(x=>x.id===id);if(n)n.read=true;save();buildNav();if(page==='notifications')$('#view').innerHTML=vNotifs()}
function markAllRead(a){S.notifications.filter(n=>n.audience===a).forEach(n=>n.read=true);save();
  if(a==='admin'){render()}else{phRender()}}
