/* =====================================================================
   CoolChain FM — Demo data & state
   assets/js/02-data.js

   Seed users, vehicles, service requests, dashboard access and notifications.
   Terminology and sample records follow the July HVAC service report.
   Held in JS rather than a JSON file so the prototype also runs from file://
   (a fetch() of local JSON is blocked by browser CORS rules).
   ===================================================================== */

function seed(){
  const U=(id,name,empId,role,area,em,mob,base,supId,vehId,join)=>({
    id,name,empId,role,destination:area,emirates:em,mobile:mob,
    email:name.toLowerCase().replace(/[^a-z]+/g,'.')+'@coolchainfm.ae',
    address:area+', '+em,joinDate:join,base,supId:supId||null,vehId:vehId||null
  });
  const users=[
    U('U1','System Administrator','EMP-001','Administrator','Head Office','Dubai','+971 50 111 0001','Available',null,null,D(2021,3,1)),
    U('U2','Ismail','EMP-014','Supervisor','Nad Al Hamar','Dubai','+971 50 222 4410','Available',null,'V1',D(2021,6,14)),
    U('U3','Arif','EMP-018','Supervisor','Ajman Industrial 1','Ajman','+971 55 331 7702','Available',null,'V3',D(2022,1,9)),
    U('U4','Rahul','EMP-021','Supervisor','Jabel Ali','Dubai','+971 52 448 1190','Available',null,'V2',D(2022,4,3)),
    U('U5','Vinod Kumar','EMP-026','Supervisor','King Faisal','Sharjah','+971 56 770 3325','Available',null,'V4',D(2023,2,20)),
    U('U6','Aravinthan','EMP-032','Technical Staff','Nad Al Hamar','Dubai','+971 55 902 1174','Available','U2','V1',D(2022,8,11)),
    U('U7','Deepu','EMP-035','Technical Staff','Nad Al Hamar','Dubai','+971 50 613 8890','Available','U2','V1',D(2022,9,5)),
    U('U8','Arun','EMP-039','Technical Staff','Jabel Ali','Dubai','+971 54 220 6641','Available','U4','V2',D(2023,1,16)),
    U('U9','Vishnu','EMP-041','Technical Staff','Ajman Industrial 1','Ajman','+971 56 118 2237','Available','U3','V3',D(2023,3,27)),
    U('U10','Sajeev','EMP-044','Technical Staff','King Faisal','Sharjah','+971 52 907 4416','Available','U5','V4',D(2023,7,2)),
    U('U11','Rasheed','EMP-047','Technical Staff','Al Nahda-2','Dubai','+971 50 388 5520','On Leave','U4',null,D(2024,2,12)),
    U('U12','Suthaharan','EMP-052','Driver','Nad Al Hamar','Dubai','+971 55 470 9931','Available','U2','V1',D(2021,11,8)),
    U('U13','Anil Joseph','EMP-055','Driver','Jabel Ali','Dubai','+971 50 226 7714','Available','U4','V2',D(2022,5,30)),
    U('U14','Mujeeb Rahman','EMP-058','Driver','Ajman Industrial 1','Ajman','+971 56 904 3382','Available','U3','V3',D(2023,6,18)),
    U('U15','Faisal Ahmed','EMP-006','Dashboard Access User','Head Office','Dubai','+971 50 700 1123','Available',null,null,D(2021,9,1)),
    U('U16','Priya Nair','EMP-009','Dashboard Access User','Head Office','Dubai','+971 55 640 2288','Available',null,null,D(2022,2,15)),
    U('U17','Mohammed Salih','EMP-061','Driver','Al Quoz','Dubai','+971 52 330 7719','Inactive',null,null,D(2024,5,6))
  ];
  const V=(id,reg,type,make,model,year,fuel,cap,loc,em,drv,sup,base,ins,rg,fit,due,notes)=>({
    id,reg,type,make,model,year,fuel,capacity:cap,location:loc,emirates:em,
    driverId:drv,supId:sup,base,insuranceExpiry:ins,regExpiry:rg,fitnessExpiry:fit,serviceDue:due,notes:notes||''
  });
  const vehicles=[
    V('V1','DXB-1234','Service Van','Toyota','Hiace',2022,'Diesel','3 crew + tools','Nad Al Hamar','Dubai','U12','U2','Available',D(2026,11,14),D(2027,2,2),D(2026,11,14),D(2026,9,20),'Gas charging kit and recovery unit on board.'),
    V('V2','DXB-4567','Service Van','Nissan','Urvan',2021,'Petrol','3 crew + tools','Jabel Ali','Dubai','U13','U4','Available',D(2026,9,30),D(2026,12,18),D(2026,9,30),D(2026,8,26),'Ladder rack fitted.'),
    V('V3','AJM-3456','Pickup','Toyota','Hilux',2023,'Diesel','2 crew + load bed','Ajman Industrial 1','Ajman','U14','U3','Available',D(2027,1,22),D(2027,1,22),D(2027,1,22),D(2026,10,11),''),
    V('V4','SHJ-7890','Service Van','Toyota','Hiace',2020,'Diesel','3 crew + tools','King Faisal','Sharjah',null,'U5','Available',D(2026,8,29),D(2026,10,5),D(2026,8,29),D(2026,8,18),'Insurance renewal due shortly.'),
    V('V5','DXB-2210','Pickup','Isuzu','D-Max',2022,'Diesel','2 crew + load bed','Al Quoz','Dubai',null,null,'Available',D(2027,3,3),D(2027,3,3),D(2027,3,3),D(2026,12,1),'Spare unit for cold room jobs.'),
    V('V6','AJM-1180','Service Van','Nissan','Urvan',2019,'Petrol','3 crew + tools','Ajman Industrial 1','Ajman',null,null,'Maintenance',D(2026,10,10),D(2026,11,7),D(2026,10,10),D(2026,8,12),'Gearbox overhaul at workshop — off road until further notice.')
  ];

  let srSeq=5070;
  const R=(o)=>{
    const base={projectNo:'',items:[],techIds:[],driverId:null,vehId:null,supId:null,
      timeIn:null,timeOut:null,hours:null,workPerformed:'',remarks:'',notes:'',material:'',
      replacement:'No',followUp:'No',timeline:[]};
    const r=Object.assign(base,o);
    if(!r.timeline.length){
      r.timeline=[{t:r.reportedDate,e:'Service request registered',by:'System Administrator'}];
      if(['Allocated','Work Started','Work Completed','Closed'].includes(r.status)){
        r.timeline.push({t:r.reportedDate+9e5,e:'Allocated to '+(users.find(u=>u.id===r.supId)||{}).name,by:'System Administrator'});
        r.timeline.push({t:r.reportedDate+96e4,e:'Assignment notification sent to supervisor',by:'System'});
      }
      if(['Work Started','Work Completed','Closed'].includes(r.status)&&r.timeIn) r.timeline.push({t:r.timeIn,e:'Work started on site',by:(users.find(u=>u.id===r.supId)||{}).name});
      if(['Work Completed','Closed'].includes(r.status)&&r.timeOut) r.timeline.push({t:r.timeOut,e:'Work completed',by:(users.find(u=>u.id===r.supId)||{}).name});
      if(r.status==='Closed') r.timeline.push({t:r.timeOut+18e5,e:'Reviewed and closed',by:'System Administrator'});
    }
    return r;
  };
  const T=(h,m)=>{const d=new Date();d.setHours(h,m,0,0);return d.getTime()};

  const requests=[
    R({srNo:'5064',projectNo:'PRJ-2026-118',client:'Nesto Hypermarket',area:'Al Nahda-2',location:'Ground floor, customer service side',emirates:'Dubai',
      serviceType:'Gas Charging',amc:'AMC',priority:'High',equipment:'Ductable AC',
      description:'Ground floor G-14 ductable AC not cooling. AC checking carried out — gas charging required.',
      items:[{floor:'Ground Floor G-14',equipment:'Ductable AC',work:'AC checking and gas charging',qty:1}],
      reportedDate:T(8,40),expectedFix:daysAgo(-1),scheduledDate:T(10,0),status:'Work Started',
      supId:'U4',techIds:['U8'],driverId:'U13',vehId:'V2',timeIn:now()-46*6e4}),
    R({srNo:'5070',projectNo:'',client:'Gulf Cold Store LLC',area:'Al Quoz',location:'Cold room 2, loading bay',emirates:'Dubai',
      serviceType:'Cooling Issue',amc:'Non-AMC',priority:'Critical',equipment:'Cold Room',
      description:'Cold room 2 holding +4°C against a −18°C set point. Suspected condenser fan fault, cooling problem to be cleared.',
      items:[{floor:'Cold room 2',equipment:'Cold Room',work:'Condenser fan checking, cooling problem clearing',qty:1},
             {floor:'Cold room 2',equipment:'Cold Room',work:'Door gasket replacement',qty:2}],
      reportedDate:T(7,55),expectedFix:daysAgo(0),scheduledDate:T(9,0),status:'Work Started',
      supId:'U5',techIds:['U10'],driverId:null,vehId:'V4',timeIn:now()-134*6e4}),
    R({srNo:'5057',projectNo:'PRJ-2026-114',client:'Nesto Hypermarket',area:'Jabel Ali',location:'Ground floor and 1st floor',emirates:'Dubai',
      serviceType:'Corrective Maintenance',amc:'AMC',priority:'Medium',equipment:'Ductable AC',
      description:'Multiple AC complaints reported by store manager across ground and first floor.',
      items:[{floor:'Ground Floor G-19',equipment:'Ductable AC',work:'Indoor fan motor removed, blower motor cleaning, water service',qty:1},
             {floor:'Ground Floor G-9',equipment:'Ductable AC',work:'Thermostat replacement',qty:1},
             {floor:'Ground Floor G-6',equipment:'Ductable AC',work:'Thermostat and indoor-to-outdoor wire replacement',qty:1},
             {floor:'1st Floor',equipment:'Cassette AC',work:'Water leakage rectification',qty:1}],
      reportedDate:T(8,10),expectedFix:daysAgo(-2),scheduledDate:T(13,0),status:'New'}),
    R({srNo:'5008',projectNo:'PRJ-2026-109',client:'Last Chance Wholesale Market LLC',area:'Ajman Industrial 1',location:'Ground floor, hot food section',emirates:'Ajman',
      serviceType:'Preventive Maintenance',amc:'AMC',priority:'Medium',equipment:'FCU',
      description:'Scheduled AMC visit — chiller water line and FCU servicing for ground floor units.',
      items:[{floor:'Ground Floor',equipment:'FCU',work:'Chiller water line strainer cleaning',qty:2},
             {floor:'Hot food section',equipment:'FCU',work:'Water service',qty:1},
             {floor:'Ground Floor',equipment:'FCU',work:'Actuator valve replacement',qty:1}],
      reportedDate:T(8,25),expectedFix:daysAgo(-1),scheduledDate:T(14,30),status:'Allocated',
      supId:'U3',techIds:['U9'],driverId:'U14',vehId:'V3'}),
    R({srNo:'5069',projectNo:'',client:'Al Maya Supermarket',area:'Mia Mall',location:'1st floor, staff area',emirates:'Sharjah',
      serviceType:'Leakage Issue',amc:'AMC',priority:'High',equipment:'Cassette AC',
      description:'Water dripping from 1st floor staff area cassette AC onto false ceiling. Drain line to be checked.',
      items:[{floor:'1st Floor',equipment:'Cassette AC',work:'Water leakage — drain line flushing and water service',qty:1}],
      reportedDate:T(9,5),expectedFix:daysAgo(-1),scheduledDate:T(16,0),status:'New'}),
    R({srNo:'5068',projectNo:'',client:'Nesto Hypermarket',area:'Al Nahda-2',location:'LV room',emirates:'Dubai',
      serviceType:'AC Checking',amc:'AMC',priority:'Medium',equipment:'Split AC',
      description:'LV room split AC tripping intermittently. AC checking requested before panel inspection.',
      items:[{floor:'LV Room',equipment:'Split AC',work:'AC checking, electrical connection tightening',qty:1}],
      reportedDate:T(9,40),expectedFix:daysAgo(-2),scheduledDate:daysAgo(-1),status:'New'}),
    R({srNo:'5067',projectNo:'PRJ-2026-121',client:'Gulf Cold Store LLC',area:'Ajman Industrial 1',location:'Roof plant area',emirates:'Ajman',
      serviceType:'Replacement',amc:'Non-AMC',priority:'Low',equipment:'AHU',
      description:'AHU filter set clogged. Quotation approved for filter replacement and water service.',
      items:[{floor:'Roof plant',equipment:'AHU',work:'Filter set replacement and filter water service',qty:6}],
      reportedDate:T(10,15),expectedFix:daysAgo(-4),scheduledDate:daysAgo(-3),status:'New'}),
    R({srNo:'5062',projectNo:'PRJ-2026-117',client:'Nesto Hypermarket',area:'Jabel Ali',location:'Ground floor G-13',emirates:'Dubai',
      serviceType:'Replacement',amc:'Non-AMC',priority:'High',equipment:'Ductable AC',
      description:'Ground floor G-13 ductable AC indoor fan motor and bearing replacement. Unit noisy and vibrating.',
      items:[{floor:'Ground Floor G-13',equipment:'Ductable AC',work:'Indoor fan motor replacement',qty:1},
             {floor:'Ground Floor G-13',equipment:'Ductable AC',work:'Bearing replacement',qty:2}],
      reportedDate:T(7,30),expectedFix:daysAgo(0),scheduledDate:T(8,0),status:'Work Completed',
      supId:'U4',techIds:['U8'],driverId:'U13',vehId:'V2',timeIn:T(8,10),timeOut:T(11,25),hours:3.25,
      workPerformed:'Indoor fan motor and both bearings replaced. Unit test run for 30 minutes.',
      remarks:'Vibration cleared, noise level normal. Store manager satisfied.',material:'Fan motor 1 no, bearing 6203 x 2',replacement:'Yes',followUp:'No'}),
    R({srNo:'5007',projectNo:'PRJ-2026-108',client:'Last Chance Wholesale Market LLC',area:'Ajman Industrial 1',location:'Ground floor',emirates:'Ajman',
      serviceType:'Water Service',amc:'AMC',priority:'Medium',equipment:'FCU',
      description:'Ground floor FCU water leakage reported. Water service required.',
      items:[{floor:'Ground Floor',equipment:'FCU',work:'Water leakage rectification and water service',qty:1}],
      reportedDate:T(7,20),expectedFix:daysAgo(0),scheduledDate:T(8,30),status:'Work Completed',
      supId:'U3',techIds:['U9'],driverId:'U14',vehId:'V3',timeIn:T(8,45),timeOut:T(10,50),hours:2.08,
      workPerformed:'FCU drain pan cleaned, drain line flushed, coil water service done.',
      remarks:'Leakage stopped. Advised client on quarterly drain cleaning.',material:'Coil cleaning chemical 2 L',replacement:'No',followUp:'No'})
  ];

  /* --- closed history spanning the last month --- */
  const hist=[
    ['5061','Nesto Hypermarket','Nad Al Hamar','Dubai','Cleaning','AMC','Medium','Ductable AC','Ground floor G-4 ductable AC blower motor cleaning and water service.','U2',['U6','U7'],'U12','V1',1,8,30,11,45],
    ['5060','Nesto Hypermarket','King Faisal','Sharjah','Gas Charging','AMC','High','Split AC','Backstore split AC low cooling — gas topped up after leak test.','U5',['U10'],null,'V4',2,9,0,12,15],
    ['5059','Last Chance Wholesale Market LLC','Ajman Industrial 1','Ajman','Repair','AMC','High','FCU','Hot food section FCU actuator valve defective — replaced.','U3',['U9'],'U14','V3',3,8,15,10,40],
    ['5058','Al Maya Supermarket','Maleha','Sharjah','Preventive Maintenance','AMC','Low','Cassette AC','Quarterly AMC visit — 6 cassette units filter water service.','U5',['U10'],null,'V4',4,8,45,13,30],
    ['5056','Nesto Hypermarket','Jabel Ali','Dubai','Electrical Work','Non-AMC','Medium','Ductable AC','G-6 indoor to outdoor wire replacement after rodent damage.','U4',['U8'],'U13','V2',6,10,0,13,10],
    ['5055','Gulf Cold Store LLC','Al Quoz','Dubai','Corrective Maintenance','Non-AMC','Critical','Freezer Unit','Freezer unit 3 not holding temperature — thermostat replaced.','U2',['U6'],'U12','V1',8,7,30,12,50],
    ['5054','Nesto Hypermarket','Mia Mall','Sharjah','Water Service','AMC','Medium','FCU','1st floor FCU chiller water line strainer cleaning.','U5',['U10'],null,'V4',11,9,15,11,55],
    ['5053','Last Chance Wholesale Market LLC','Ajman Industrial 1','Ajman','Cleaning','AMC','Low','AHU','AHU filter water service and coil cleaning.','U3',['U9'],'U14','V3',14,8,20,12,5],
    ['5052','Nesto Hypermarket','Al Nahda-2','Dubai','Repair','AMC','High','Cassette AC','Customer service area cassette AC water leakage — drain pump replaced.','U4',['U8','U6'],'U13','V2',18,9,45,14,20],
    ['5051','Al Maya Supermarket','Mia Mall','Sharjah','Replacement','Non-AMC','Medium','Ductable AC','Ductable AC fan bearing replacement after abnormal noise.','U2',['U7'],'U12','V1',22,8,0,11,30],
    ['5050','Gulf Cold Store LLC','Al Quoz','Dubai','Preventive Maintenance','AMC','Low','Chiller','Monthly chiller preventive maintenance and log review.','U5',['U10'],null,'V4',26,8,30,15,0]
  ];
  hist.forEach(h=>{
    const day=h[13];
    const mk=(hh,mm)=>{const x=new Date();x.setDate(x.getDate()-day);x.setHours(hh,mm,0,0);return x.getTime()};
    const tin=mk(h[14],h[15]),tout=mk(h[16],h[17]);
    requests.push(R({srNo:h[0],projectNo:'',client:h[1],area:h[2],location:h[2],emirates:h[3],serviceType:h[4],amc:h[5],
      priority:h[6],equipment:h[7],description:h[8],
      items:[{floor:h[2],equipment:h[7],work:h[4],qty:1}],
      reportedDate:tin-72e5,expectedFix:tout,scheduledDate:tin,status:'Closed',
      supId:h[9],techIds:h[10],driverId:h[11],vehId:h[12],timeIn:tin,timeOut:tout,hours:hoursOf(tin,tout),
      workPerformed:h[8],remarks:'Work completed and signed off by client representative.',replacement:h[4]==='Replacement'?'Yes':'No',followUp:'No'}));
  });

  const dashAccess=[
    {id:'DA1',userId:'U1',scope:'Full dashboard',enabled:true,lastLogin:now()-25*6e4},
    {id:'DA2',userId:'U15',scope:'Operations + reports',enabled:true,lastLogin:now()-3*36e5},
    {id:'DA3',userId:'U16',scope:'Reports only',enabled:false,lastLogin:now()-4*864e5},
    {id:'DA4',userId:'U2',scope:'Own team only',enabled:true,lastLogin:now()-70*6e4}
  ];

  return {users,vehicles,requests,dashAccess,notifications:[],srSeq:5071};
}

/* ---------- state ---------- */
let S;
function load(){
  const raw=store.get(KEY);
  if(raw){try{S=JSON.parse(raw);if(S&&S.requests&&S.requests.length)return}catch(e){}}
  S=seed();
  seedNotifs();
  save();
}
function save(){try{store.set(KEY,JSON.stringify(S))}catch(e){}}
function resetAll(){store.del(KEY);store.del(KEY+'.session');S=seed();seedNotifs();save();closeModal();render();toast('Demo data reset','All users, vehicles and service requests restored to the sample set.','ok')}

function seedNotifs(){
  S.notifications=[];
  const started=S.requests.filter(r=>r.status==='Work Started');
  const done=S.requests.filter(r=>r.status==='Work Completed');
  notify('supervisor','New service request assigned',`SR #5064 · Nesto Hypermarket\nAl Nahda-2, Dubai\nDuctable AC — Gas Charging\nPriority: High`,'U4',now()-58*6e4,'5064');
  started.forEach(r=>notify('admin','Work started',`SR #${r.srNo} · ${r.client} — ${sup(r)?sup(r).name:'—'} started on site.`,null,r.timeIn,r.srNo));
  done.forEach(r=>notify('admin','Work completed',`SR #${r.srNo} · ${r.client} — ${r.hours} h recorded.`,null,r.timeOut,r.srNo));
  notify('admin','Vehicle unavailable','AJM-1180 moved to Maintenance — gearbox overhaul at workshop.',null,now()-6*36e5);
  notify('admin','User unavailable','Rasheed (EMP-047) is On Leave until further notice.',null,now()-9*36e5);
  const overdue=S.requests.find(r=>r.srNo==='5067');
  if(overdue) notify('admin','Service overdue',`SR #5067 · Gulf Cold Store LLC — expected fix date has passed and the request is still New.`,null,now()-2*36e5,'5067');
  notify('supervisor','Work reminder','SR #5008 · Last Chance Wholesale Market LLC, Ajman is scheduled for 02:30 PM today.','U3',now()-40*6e4,'5008');
  notify('supervisor','New service request assigned',`SR #5008 · Last Chance Wholesale Market LLC\nAjman Industrial 1, Ajman\nFCU — Preventive Maintenance\nPriority: Medium`,'U3',now()-52*6e4,'5008');
}
function notify(audience,title,body,userId,t,srNo){
  S.notifications.unshift({id:uid('N'),audience,title,body,userId:userId||null,t:t||now(),read:false,srNo:srNo||null});
}
