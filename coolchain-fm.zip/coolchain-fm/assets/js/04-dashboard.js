/* =====================================================================
   CoolChain FM — Admin dashboard
   assets/js/04-dashboard.js

   Statistic tiles, the deployment gauge, current operations table and charts.
   ===================================================================== */

function counts(){
  const R=S.requests,t=R.filter(r=>isToday(r.reportedDate));
  const wk=R.filter(r=>r.reportedDate>=daysAgo(7)),mo=R.filter(r=>r.reportedDate>=daysAgo(30));
  const fu=fieldUsers();
  return {
    today:t.length,
    tDone:R.filter(r=>isToday(r.timeOut)).length,
    tPend:t.filter(r=>r.status==='New').length,
    tAlloc:R.filter(r=>r.status==='Allocated').length,
    tStart:R.filter(r=>r.status==='Work Started').length,
    wk:wk.length,mo:mo.length,
    uActive:S.users.filter(u=>u.base!=='Inactive').length,
    uFree:fu.filter(u=>uStatus(u.id)==='Available').length,
    uWork:fu.filter(u=>['Working','Assigned'].includes(uStatus(u.id))).length,
    vAll:S.vehicles.length,
    vFree:S.vehicles.filter(v=>vStatus(v.id)==='Available').length,
    vBusy:S.vehicles.filter(v=>['Assigned','In Service'].includes(vStatus(v.id))).length,
    vMaint:S.vehicles.filter(v=>vStatus(v.id)==='Maintenance').length,
    open:R.filter(r=>['New','Allocated','Work Started'].includes(r.status)).length,
    closed:R.filter(r=>['Work Completed','Closed'].includes(r.status)).length,
    amc:R.filter(r=>r.amc==='AMC').length,
    nonamc:R.filter(r=>r.amc==='Non-AMC').length
  };
}
function statCard(k,v,m,c){return `<div class="stat ${c||''}"><div class="k">${k}</div><div class="v">${v}</div><div class="m">${m||''}</div></div>`}

function vDash(){
  const c=counts(),fu=fieldUsers();
  const total=fu.length||1;
  const free=c.uFree,work=fu.filter(u=>uStatus(u.id)==='Working').length,asg=fu.filter(u=>uStatus(u.id)==='Assigned').length,
        leave=fu.filter(u=>uStatus(u.id)==='On Leave').length,inact=fu.filter(u=>uStatus(u.id)==='Inactive').length;
  const pc=n=>(n/total*100).toFixed(0);
  const live=S.requests.filter(r=>ACTIVE.includes(r.status)).sort((a,b)=>SRSTATUS.indexOf(b.status)-SRSTATUS.indexOf(a.status));
  later(drawCharts);later(startTickers);
  return `
  <div class="gauge">
    <div class="gauge-row">
      <div class="gauge-num"><small>Crew deployed</small>${work+asg}<span style="font-size:17px;color:rgba(255,255,255,.45)">/${total}</span></div>
      <div class="gauge-num"><small>Vans out</small>${c.vBusy}<span style="font-size:17px;color:rgba(255,255,255,.45)">/${c.vAll}</span></div>
      <div class="gauge-num"><small>Jobs running</small>${c.tStart}</div>
      <div class="gauge-num"><small>Awaiting allocation</small>${c.tPend}</div>
      <div style="margin-left:auto;text-align:right">
        <div class="eyebrow" style="color:rgba(255,255,255,.45)">Load right now</div>
        <div class="gauge-num" style="font-size:30px">${pc(work+asg)}%</div>
      </div>
    </div>
    <div class="bar">
      <i style="width:${pc(work)}%;background:#D9822B"></i>
      <i style="width:${pc(asg)}%;background:#5B54B8"></i>
      <i style="width:${pc(free)}%;background:#17B7D4"></i>
      <i style="width:${pc(leave+inact)}%;background:#5A6A7D"></i>
    </div>
    <div class="bar-key">
      <span><b style="background:#D9822B"></b>Working ${work}</span>
      <span><b style="background:#5B54B8"></b>Assigned ${asg}</span>
      <span><b style="background:#17B7D4"></b>Available ${free}</span>
      <span><b style="background:#5A6A7D"></b>On leave / inactive ${leave+inact}</span>
    </div>
  </div>

  <div class="sec-h"><h2>Today</h2><span class="rule"></span></div>
  <div class="stat-grid">
    ${statCard("Today's service requests",c.today,'Registered since midnight','c')}
    ${statCard("Today's completed jobs",c.tDone,'Signed off on site','d')}
    ${statCard("Today's pending jobs",c.tPend,'Not yet allocated','h')}
    ${statCard("Today's allocated jobs",c.tAlloc,'Crew and van assigned','v')}
    ${statCard("Today's work started",c.tStart,'Crew on site now','w')}
    ${statCard('Last 7 days',c.wk,'Service requests')}
    ${statCard('Last month',c.mo,'Service requests')}
    ${statCard('Open complaints',c.open,'New, allocated or running','h')}
    ${statCard('Completed complaints',c.closed,'Completed or closed','d')}
  </div>

  <div class="sec-h"><h2>Workforce &amp; fleet</h2><span class="rule"></span></div>
  <div class="stat-grid">
    ${statCard('Total active users',c.uActive,'All roles')}
    ${statCard('Available users',c.uFree,'Ready to dispatch','c')}
    ${statCard('Users currently working',c.uWork,'On an active request','w')}
    ${statCard('Total vehicles',c.vAll,'Service fleet')}
    ${statCard('Available vehicles',c.vFree,'Ready to dispatch','c')}
    ${statCard('Vehicles assigned',c.vBusy,'Allocated or in service','w')}
    ${statCard('Under maintenance',c.vMaint,'Off road','h')}
    ${statCard('AMC share',(c.amc/(c.amc+c.nonamc)*100).toFixed(0)+'%',`${c.amc} AMC · ${c.nonamc} Non-AMC`,'v')}
  </div>

  <div class="sec-h"><h2>Current service operations</h2><span class="rule"></span>
    <button class="btn btn-sm" onclick="go('requests')">All requests</button></div>
  <div class="card"><div class="tbl-wrap"><table>
    <thead><tr><th>SR No</th><th>Client</th><th>Location</th><th>Issue</th><th>Supervisor</th><th>Crew</th><th>Vehicle</th><th>Started</th><th>Elapsed</th><th>Status</th><th></th></tr></thead>
    <tbody>${live.length?live.map(r=>`<tr>
      <td><span class="sr-no">#${r.srNo}</span></td>
      <td><b>${esc(r.client)}</b><div class="eyebrow">${esc(r.amc)}</div></td>
      <td>${esc(r.area)}<div style="color:var(--txt-3);font-size:11.5px">${esc(r.emirates)}</div></td>
      <td>${esc(r.serviceType)}<div style="color:var(--txt-3);font-size:11.5px">${esc(r.equipment)}</div></td>
      <td>${sup(r)?`<div class="who">${av(sup(r).name,26)}<b>${esc(sup(r).name)}</b></div>`:'<span style="color:var(--txt-3)">Unassigned</span>'}</td>
      <td>${(r.techIds||[]).map(i=>esc((user(i)||{}).name)).join(', ')||'—'}</td>
      <td class="mono">${r.vehId?esc(veh(r.vehId).reg):'—'}</td>
      <td class="mono">${r.timeIn?fmtTime(r.timeIn):'—'}</td>
      <td>${r.timeIn?`<span class="live" data-tick="${r.timeIn}">${dur(now()-r.timeIn)}</span>`:'—'}</td>
      <td>${bdg(r.status)}</td>
      <td><button class="btn btn-sm" onclick="viewSR('${r.srNo}')">Open</button></td>
    </tr>`).join(''):`<tr><td colspan="11" class="t-empty">${emptyArt('')}<b>Nothing running</b>Allocate a service request to see live operations here.</td></tr>`}</tbody>
  </table></div></div>

  <div class="sec-h"><h2>Charts</h2><span class="rule"></span></div>
  <div class="chart-grid">
    <div class="card"><div class="card-h"><h3>Service request trend</h3><span class="eyebrow" style="margin-left:auto">Volume by window</span></div>
      <div class="card-b"><div class="chart-box"><canvas id="cTrend"></canvas></div></div></div>
    <div class="card"><div class="card-h"><h3>Service status</h3></div>
      <div class="card-b"><div class="chart-box"><canvas id="cStatus"></canvas></div></div></div>
  </div>
  <div class="chart-grid-3" style="margin-top:14px">
    <div class="card"><div class="card-h"><h3>AMC vs Non-AMC</h3></div><div class="card-b"><div class="chart-box"><canvas id="cAmc"></canvas></div></div></div>
    <div class="card"><div class="card-h"><h3>Priority distribution</h3></div><div class="card-b"><div class="chart-box"><canvas id="cPrio"></canvas></div></div></div>
    <div class="card"><div class="card-h"><h3>Employee status</h3></div><div class="card-b"><div class="chart-box"><canvas id="cEmp"></canvas></div></div></div>
  </div>
  <div class="chart-grid" style="margin-top:14px">
    <div class="card"><div class="card-h"><h3>Vehicle status</h3></div><div class="card-b"><div class="chart-box"><canvas id="cVeh"></canvas></div></div></div>
    <div class="card"><div class="card-h"><h3>Service type mix</h3><span class="eyebrow" style="margin-left:auto">Top activities</span></div><div class="card-b"><div class="chart-box"><canvas id="cType"></canvas></div></div></div>
  </div>`;
}

let charts=[];
function drawCharts(){
  if(!window.Chart)return;
  charts.forEach(c=>{try{c.destroy()}catch(e){}});charts=[];
  Chart.defaults.font.family="Inter, sans-serif";Chart.defaults.font.size=11;Chart.defaults.color='#4B5D73';
  const C={cool:'#0E8FA8',warm:'#D9822B',hot:'#C8453C',done:'#1E8E5A',idle:'#8393A6',violet:'#5B54B8',ice:'#17B7D4'};
  const mk=(id,cfg)=>{const el=document.getElementById(id);if(el)charts.push(new Chart(el,cfg))};
  const R=S.requests;
  const y=(()=>{const d=new Date();d.setDate(d.getDate()-1);return R.filter(r=>new Date(r.reportedDate).toDateString()===d.toDateString()).length})();
  const noLeg={plugins:{legend:{display:false}}};
  mk('cTrend',{type:'bar',data:{labels:['Today','Yesterday','Last 7 days','Last 30 days'],
    datasets:[{data:[R.filter(r=>isToday(r.reportedDate)).length,y,R.filter(r=>r.reportedDate>=daysAgo(7)).length,R.filter(r=>r.reportedDate>=daysAgo(30)).length],
      backgroundColor:[C.ice,C.cool,C.violet,'#2E4A63'],borderRadius:6,maxBarThickness:56}]},
    options:{responsive:true,maintainAspectRatio:false,...noLeg,scales:{y:{beginAtZero:true,grid:{color:'#EEF1F5'},ticks:{precision:0}},x:{grid:{display:false}}}}});
  const stCount=['New','Allocated','Work Started','Work Completed','Closed'].map(s=>R.filter(r=>r.status===s).length);
  mk('cStatus',{type:'doughnut',data:{labels:['New','Allocated','Work Started','Work Completed','Closed'],
    datasets:[{data:stCount,backgroundColor:[C.idle,C.violet,C.warm,C.done,C.cool],borderWidth:2,borderColor:'#fff'}]},
    options:{responsive:true,maintainAspectRatio:false,cutout:'62%',plugins:{legend:{position:'right',labels:{boxWidth:9,boxHeight:9,usePointStyle:true,pointStyle:'rectRounded'}}}}});
  mk('cAmc',{type:'doughnut',data:{labels:['AMC','Non-AMC'],datasets:[{data:[R.filter(r=>r.amc==='AMC').length,R.filter(r=>r.amc==='Non-AMC').length],
    backgroundColor:[C.cool,C.violet],borderWidth:2,borderColor:'#fff'}]},
    options:{responsive:true,maintainAspectRatio:false,cutout:'58%',plugins:{legend:{position:'bottom',labels:{boxWidth:9,usePointStyle:true,pointStyle:'rectRounded'}}}}});
  mk('cPrio',{type:'bar',data:{labels:PRIOS.slice().reverse(),datasets:[{data:PRIOS.slice().reverse().map(p=>R.filter(r=>r.priority===p).length),
    backgroundColor:[C.hot,C.warm,C.cool,C.idle],borderRadius:6,maxBarThickness:34}]},
    options:{indexAxis:'y',responsive:true,maintainAspectRatio:false,...noLeg,scales:{x:{beginAtZero:true,grid:{color:'#EEF1F5'},ticks:{precision:0}},y:{grid:{display:false}}}}});
  const fu=fieldUsers();
  mk('cEmp',{type:'doughnut',data:{labels:USTATUS,datasets:[{data:USTATUS.map(s=>fu.filter(u=>uStatus(u.id)===s).length),
    backgroundColor:[C.cool,C.warm,C.violet,C.idle,'#C3CCD8'],borderWidth:2,borderColor:'#fff'}]},
    options:{responsive:true,maintainAspectRatio:false,cutout:'58%',plugins:{legend:{position:'bottom',labels:{boxWidth:9,usePointStyle:true,pointStyle:'rectRounded',font:{size:10}}}}}});
  mk('cVeh',{type:'bar',data:{labels:VSTATUS,datasets:[{data:VSTATUS.map(s=>S.vehicles.filter(v=>vStatus(v.id)===s).length),
    backgroundColor:[C.cool,C.violet,C.warm,C.hot,C.idle],borderRadius:6,maxBarThickness:48}]},
    options:{responsive:true,maintainAspectRatio:false,...noLeg,scales:{y:{beginAtZero:true,grid:{color:'#EEF1F5'},ticks:{precision:0}},x:{grid:{display:false}}}}});
  const tc={};R.forEach(r=>tc[r.serviceType]=(tc[r.serviceType]||0)+1);
  const top=Object.entries(tc).sort((a,b)=>b[1]-a[1]).slice(0,7);
  mk('cType',{type:'bar',data:{labels:top.map(t=>t[0]),datasets:[{data:top.map(t=>t[1]),backgroundColor:C.ice,borderRadius:5,maxBarThickness:22}]},
    options:{indexAxis:'y',responsive:true,maintainAspectRatio:false,...noLeg,scales:{x:{beginAtZero:true,grid:{color:'#EEF1F5'},ticks:{precision:0}},y:{grid:{display:false}}}}});
}
let tickTimer=null;
function startTickers(){
  if(tickTimer)clearInterval(tickTimer);
  const run=()=>document.querySelectorAll('[data-tick]').forEach(el=>{el.textContent=dur(now()-Number(el.dataset.tick))});
  run();tickTimer=setInterval(run,1000);
}
