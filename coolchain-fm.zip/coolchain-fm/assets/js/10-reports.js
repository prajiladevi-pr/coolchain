/* =====================================================================
   CoolChain FM — Reports
   assets/js/10-reports.js

   Service request, employee work, vehicle and AMC / Non-AMC reporting.
   ===================================================================== */

let repTab='service';
function vReports(){
  const T=[['service','Service request report'],['employee','Employee work report'],['vehicle','Vehicle report'],['amc','AMC / Non-AMC report']];
  return `<div class="card">
    <div class="tabs">${T.map(t=>`<button class="tab ${repTab===t[0]?'on':''}" onclick="repTab='${t[0]}';render()">${t[1]}</button>`).join('')}</div>
    ${repTab==='service'?repService():repTab==='employee'?repEmployee():repTab==='vehicle'?repVehicle():repAmc()}
  </div>`;
}
const csvBtn=`<button class="btn btn-sm" style="margin-left:auto" onclick="toast('Export queued','A CSV export would download here. This prototype keeps the data on screen.')">${icon('dl',14)} Export</button>`;
function repService(){
  const f=F.sr,list=filterSR();
  const hrs=list.filter(r=>r.hours).reduce((a,r)=>a+r.hours,0);
  return `<div class="bar-tools">
      <input class="inp" type="date" value="${f.from}" onchange="setF('sr','from',this.value)" title="From">
      <input class="inp" type="date" value="${f.to}" onchange="setF('sr','to',this.value)" title="To">
      <select class="inp" onchange="setF('sr','client',this.value)">${opts(CLIENTS,f.client,'All clients')}</select>
      <select class="inp" onchange="setF('sr','em',this.value)">${opts(EMIRATES,f.em,'All emirates')}</select>
      <select class="inp" onchange="setF('sr','amc',this.value)">${opts(['AMC','Non-AMC'],f.amc,'AMC / Non-AMC')}</select>
      <select class="inp" onchange="setF('sr','sup',this.value)">${opts(S.users.filter(u=>u.role==='Supervisor').map(u=>({v:u.id,l:u.name})),f.sup,'All supervisors')}</select>
      <select class="inp" onchange="setF('sr','status',this.value)">${opts(SRSTATUS,f.status,'All statuses')}</select>
      <button class="btn btn-sm" onclick="clearF('sr')">Clear</button>${csvBtn}</div>
    <div class="card-b">
      <div class="stat-grid" style="grid-template-columns:repeat(5,1fr);margin-bottom:16px">
        ${statCard('Requests',list.length,'In selection','c')}
        ${statCard('Completed',list.filter(r=>['Work Completed','Closed'].includes(r.status)).length,'','d')}
        ${statCard('Open',list.filter(r=>['New','Allocated','Work Started'].includes(r.status)).length,'','h')}
        ${statCard('Working hours',hrs.toFixed(1),'Recorded','w')}
        ${statCard('Avg hours / job',list.filter(r=>r.hours).length?(hrs/list.filter(r=>r.hours).length).toFixed(2):'0','On completed jobs','v')}
      </div>
      ${list.length?`<div class="tbl-wrap card" style="box-shadow:none"><table>
        <thead><tr><th>Date</th><th>SR No</th><th>Client</th><th>Area</th><th>Emirates</th><th>Service</th><th>Contract</th><th>Priority</th><th>Supervisor</th><th>Vehicle</th><th>Hours</th><th>Status</th></tr></thead>
        <tbody>${list.map(r=>`<tr><td class="mono" style="font-size:11.5px">${fmtDate(r.reportedDate)}</td><td><span class="sr-no">#${r.srNo}</span></td>
          <td>${esc(r.client)}</td><td>${esc(r.area)}</td><td>${esc(r.emirates)}</td><td>${esc(r.serviceType)}</td>
          <td>${bdg(r.amc,1)}</td><td>${bdg(r.priority,1)}</td><td>${sup(r)?esc(sup(r).name):'—'}</td>
          <td class="mono">${r.vehId?esc(veh(r.vehId).reg):'—'}</td><td class="mono">${r.hours!=null?r.hours:'—'}</td><td>${bdg(r.status)}</td></tr>`).join('')}</tbody></table></div>`
      :`<div class="t-empty"><b>Nothing in this selection</b>Widen the date range or clear the filters.</div>`}
    </div>`;
}
function repEmployee(){
  const rows=fieldUsers().map(u=>{
    const h=historyOf(u.id);
    return {u,total:h.length,done:h.filter(r=>['Work Completed','Closed'].includes(r.status)).length,
      hrs:h.filter(r=>r.hours).reduce((a,r)=>a+r.hours,0),
      amc:h.filter(r=>r.amc==='AMC').length,non:h.filter(r=>r.amc==='Non-AMC').length};
  }).sort((a,b)=>b.hrs-a.hrs);
  later(()=>{
    if(!window.Chart)return;
    const el=document.getElementById('cEmpRep');if(!el)return;
    charts.push(new Chart(el,{type:'bar',data:{labels:rows.map(r=>r.u.name),
      datasets:[{label:'AMC jobs',data:rows.map(r=>r.amc),backgroundColor:'#0E8FA8',borderRadius:4,stack:'s'},
                {label:'Non-AMC jobs',data:rows.map(r=>r.non),backgroundColor:'#5B54B8',borderRadius:4,stack:'s'}]},
      options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{position:'bottom',labels:{boxWidth:9,usePointStyle:true,pointStyle:'rectRounded'}}},
        scales:{x:{stacked:true,grid:{display:false}},y:{stacked:true,beginAtZero:true,grid:{color:'#EEF1F5'},ticks:{precision:0}}}}}));
  });
  return `<div class="bar-tools"><span class="eyebrow">Jobs and hours per employee, all time</span>${csvBtn}</div>
    <div class="card-b">
      <div class="chart-box" style="height:270px;margin-bottom:18px"><canvas id="cEmpRep"></canvas></div>
      <div class="tbl-wrap card" style="box-shadow:none"><table>
        <thead><tr><th>Employee</th><th>Role</th><th>Total jobs</th><th>Completed</th><th>AMC</th><th>Non-AMC</th><th>Working hours</th><th>Avg / job</th><th>Status</th><th></th></tr></thead>
        <tbody>${rows.map(r=>`<tr>
          <td><div class="who">${av(r.u.name)}<div><b>${esc(r.u.name)}</b><small>${esc(r.u.empId)}</small></div></div></td>
          <td>${esc(r.u.role)}</td><td class="mono">${r.total}</td><td class="mono">${r.done}</td>
          <td class="mono">${r.amc}</td><td class="mono">${r.non}</td><td class="mono">${r.hrs.toFixed(1)}</td>
          <td class="mono">${r.total?(r.hrs/r.total).toFixed(2):'0'}</td><td>${bdg(uStatus(r.u.id))}</td>
          <td><button class="btn btn-sm" onclick="openHistory('${r.u.id}')">History</button></td></tr>`).join('')}</tbody></table></div>
    </div>`;
}
function repVehicle(){
  const rows=S.vehicles.map(v=>{const j=S.requests.filter(r=>r.vehId===v.id);
    return {v,jobs:j.length,hrs:j.filter(r=>r.hours).reduce((a,r)=>a+r.hours,0)}}).sort((a,b)=>b.jobs-a.jobs);
  return `<div class="bar-tools"><span class="eyebrow">Fleet utilisation, all time</span>${csvBtn}</div>
    <div class="card-b"><div class="tbl-wrap card" style="box-shadow:none"><table>
      <thead><tr><th>Vehicle</th><th>Type</th><th>Driver</th><th>Jobs</th><th>Working hours</th><th>Avg / job</th><th>Location</th><th>Service due</th><th>Current status</th><th></th></tr></thead>
      <tbody>${rows.map(r=>`<tr><td><b class="mono">${esc(r.v.reg)}</b><div class="eyebrow">${esc(r.v.make)} ${esc(r.v.model)}</div></td>
        <td>${esc(r.v.type)}</td><td>${r.v.driverId?esc(user(r.v.driverId).name):'—'}</td>
        <td class="mono">${r.jobs}</td><td class="mono">${r.hrs.toFixed(1)}</td><td class="mono">${r.jobs?(r.hrs/r.jobs).toFixed(2):'0'}</td>
        <td>${esc(r.v.location)}</td><td class="mono" style="font-size:11.5px">${fmtDate(r.v.serviceDue)}</td>
        <td>${bdg(vStatus(r.v.id))}</td><td><button class="btn btn-sm" onclick="vehHistory('${r.v.id}')">History</button></td></tr>`).join('')}</tbody></table></div></div>`;
}
function repAmc(){
  const byClient={};
  S.requests.forEach(r=>{const k=r.client;byClient[k]=byClient[k]||{amc:0,non:0,hrs:0};byClient[k][r.amc==='AMC'?'amc':'non']++;byClient[k].hrs+=r.hours||0});
  const amc=S.requests.filter(r=>r.amc==='AMC').length,non=S.requests.length-amc;
  later(()=>{
    if(!window.Chart)return;
    const el=document.getElementById('cAmcRep');if(!el)return;
    charts.push(new Chart(el,{type:'bar',data:{labels:Object.keys(byClient),
      datasets:[{label:'AMC',data:Object.values(byClient).map(v=>v.amc),backgroundColor:'#0E8FA8',borderRadius:5},
                {label:'Non-AMC',data:Object.values(byClient).map(v=>v.non),backgroundColor:'#5B54B8',borderRadius:5}]},
      options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{position:'bottom',labels:{boxWidth:9,usePointStyle:true,pointStyle:'rectRounded'}}},
        scales:{y:{beginAtZero:true,grid:{color:'#EEF1F5'},ticks:{precision:0}},x:{grid:{display:false}}}}}));
  });
  return `<div class="bar-tools"><span class="eyebrow">Contract mix by client</span>${csvBtn}</div>
    <div class="card-b">
      <div class="stat-grid" style="grid-template-columns:repeat(4,1fr);margin-bottom:18px">
        ${statCard('AMC requests',amc,(amc/S.requests.length*100).toFixed(0)+'% of volume','c')}
        ${statCard('Non-AMC requests',non,(non/S.requests.length*100).toFixed(0)+'% of volume','v')}
        ${statCard('AMC hours',S.requests.filter(r=>r.amc==='AMC').reduce((a,r)=>a+(r.hours||0),0).toFixed(1),'On site','w')}
        ${statCard('Non-AMC hours',S.requests.filter(r=>r.amc==='Non-AMC').reduce((a,r)=>a+(r.hours||0),0).toFixed(1),'Billable','h')}
      </div>
      <div class="chart-box" style="height:270px;margin-bottom:18px"><canvas id="cAmcRep"></canvas></div>
      <div class="tbl-wrap card" style="box-shadow:none"><table>
        <thead><tr><th>Client</th><th>AMC jobs</th><th>Non-AMC jobs</th><th>Total</th><th>AMC share</th><th>Working hours</th></tr></thead>
        <tbody>${Object.entries(byClient).map(([k,v])=>`<tr><td><b>${esc(k)}</b></td><td class="mono">${v.amc}</td><td class="mono">${v.non}</td>
          <td class="mono">${v.amc+v.non}</td><td class="mono">${((v.amc/(v.amc+v.non))*100).toFixed(0)}%</td><td class="mono">${v.hrs.toFixed(1)}</td></tr>`).join('')}</tbody></table></div>
    </div>`;
}
